gdjs.TutorialCode = {};
gdjs.TutorialCode.GDBottomObjects1_1final = [];

gdjs.TutorialCode.GDPlayerObjects1_1final = [];

gdjs.TutorialCode.GDPlayerObjects2_1final = [];

gdjs.TutorialCode.GDPlatformObjects1= [];
gdjs.TutorialCode.GDPlatformObjects2= [];
gdjs.TutorialCode.GDPlatformObjects3= [];
gdjs.TutorialCode.GDPlatformObjects4= [];
gdjs.TutorialCode.GDghostObjects1= [];
gdjs.TutorialCode.GDghostObjects2= [];
gdjs.TutorialCode.GDghostObjects3= [];
gdjs.TutorialCode.GDghostObjects4= [];
gdjs.TutorialCode.GDGhost1RightObjects1= [];
gdjs.TutorialCode.GDGhost1RightObjects2= [];
gdjs.TutorialCode.GDGhost1RightObjects3= [];
gdjs.TutorialCode.GDGhost1RightObjects4= [];
gdjs.TutorialCode.GDGhost1LeftObjects1= [];
gdjs.TutorialCode.GDGhost1LeftObjects2= [];
gdjs.TutorialCode.GDGhost1LeftObjects3= [];
gdjs.TutorialCode.GDGhost1LeftObjects4= [];
gdjs.TutorialCode.GDPlatform2Objects1= [];
gdjs.TutorialCode.GDPlatform2Objects2= [];
gdjs.TutorialCode.GDPlatform2Objects3= [];
gdjs.TutorialCode.GDPlatform2Objects4= [];
gdjs.TutorialCode.GDCoinObjects1= [];
gdjs.TutorialCode.GDCoinObjects2= [];
gdjs.TutorialCode.GDCoinObjects3= [];
gdjs.TutorialCode.GDCoinObjects4= [];
gdjs.TutorialCode.GDNewTextObjects1= [];
gdjs.TutorialCode.GDNewTextObjects2= [];
gdjs.TutorialCode.GDNewTextObjects3= [];
gdjs.TutorialCode.GDNewTextObjects4= [];
gdjs.TutorialCode.GDNewText2Objects1= [];
gdjs.TutorialCode.GDNewText2Objects2= [];
gdjs.TutorialCode.GDNewText2Objects3= [];
gdjs.TutorialCode.GDNewText2Objects4= [];
gdjs.TutorialCode.GDNewSpriteObjects1= [];
gdjs.TutorialCode.GDNewSpriteObjects2= [];
gdjs.TutorialCode.GDNewSpriteObjects3= [];
gdjs.TutorialCode.GDNewSpriteObjects4= [];
gdjs.TutorialCode.GDWallObjects1= [];
gdjs.TutorialCode.GDWallObjects2= [];
gdjs.TutorialCode.GDWallObjects3= [];
gdjs.TutorialCode.GDWallObjects4= [];
gdjs.TutorialCode.GDMovingfrfrfObjects1= [];
gdjs.TutorialCode.GDMovingfrfrfObjects2= [];
gdjs.TutorialCode.GDMovingfrfrfObjects3= [];
gdjs.TutorialCode.GDMovingfrfrfObjects4= [];
gdjs.TutorialCode.GDdashObjects1= [];
gdjs.TutorialCode.GDdashObjects2= [];
gdjs.TutorialCode.GDdashObjects3= [];
gdjs.TutorialCode.GDdashObjects4= [];
gdjs.TutorialCode.GDjumpghostObjects1= [];
gdjs.TutorialCode.GDjumpghostObjects2= [];
gdjs.TutorialCode.GDjumpghostObjects3= [];
gdjs.TutorialCode.GDjumpghostObjects4= [];
gdjs.TutorialCode.GDhitskeleObjects1= [];
gdjs.TutorialCode.GDhitskeleObjects2= [];
gdjs.TutorialCode.GDhitskeleObjects3= [];
gdjs.TutorialCode.GDhitskeleObjects4= [];
gdjs.TutorialCode.GDDetector_9595tm_9595Objects1= [];
gdjs.TutorialCode.GDDetector_9595tm_9595Objects2= [];
gdjs.TutorialCode.GDDetector_9595tm_9595Objects3= [];
gdjs.TutorialCode.GDDetector_9595tm_9595Objects4= [];
gdjs.TutorialCode.GDbedObjects1= [];
gdjs.TutorialCode.GDbedObjects2= [];
gdjs.TutorialCode.GDbedObjects3= [];
gdjs.TutorialCode.GDbedObjects4= [];
gdjs.TutorialCode.GDBedWinObjects1= [];
gdjs.TutorialCode.GDBedWinObjects2= [];
gdjs.TutorialCode.GDBedWinObjects3= [];
gdjs.TutorialCode.GDBedWinObjects4= [];
gdjs.TutorialCode.GDBackgroundObjects1= [];
gdjs.TutorialCode.GDBackgroundObjects2= [];
gdjs.TutorialCode.GDBackgroundObjects3= [];
gdjs.TutorialCode.GDBackgroundObjects4= [];
gdjs.TutorialCode.GDSkeletonObjects1= [];
gdjs.TutorialCode.GDSkeletonObjects2= [];
gdjs.TutorialCode.GDSkeletonObjects3= [];
gdjs.TutorialCode.GDSkeletonObjects4= [];
gdjs.TutorialCode.GDSanity_9595BarObjects1= [];
gdjs.TutorialCode.GDSanity_9595BarObjects2= [];
gdjs.TutorialCode.GDSanity_9595BarObjects3= [];
gdjs.TutorialCode.GDSanity_9595BarObjects4= [];
gdjs.TutorialCode.GDPlayerObjects1= [];
gdjs.TutorialCode.GDPlayerObjects2= [];
gdjs.TutorialCode.GDPlayerObjects3= [];
gdjs.TutorialCode.GDPlayerObjects4= [];
gdjs.TutorialCode.GDBottomObjects1= [];
gdjs.TutorialCode.GDBottomObjects2= [];
gdjs.TutorialCode.GDBottomObjects3= [];
gdjs.TutorialCode.GDBottomObjects4= [];


gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.TutorialCode.GDPlayerObjects2});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDghostObjects2Objects = Hashtable.newFrom({"ghost": gdjs.TutorialCode.GDghostObjects2});
gdjs.TutorialCode.asyncCallback16035836 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects3);

{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects3[i].getBehavior("PlatformerObject").setCanNotAirJump();
}
}}
gdjs.TutorialCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.TutorialCode.GDPlayerObjects2) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.15), (runtimeScene) => (gdjs.TutorialCode.asyncCallback16035836(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback16038612 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects3);

{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects3[i].getBehavior("PlatformerObject").setCanNotAirJump();
}
}}
gdjs.TutorialCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.TutorialCode.GDPlayerObjects2) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.15), (runtimeScene) => (gdjs.TutorialCode.asyncCallback16038612(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() != "WalkRight" ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDPlayerObjects2[k] = gdjs.TutorialCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationIndex(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkRight" ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDPlayerObjects2[k] = gdjs.TutorialCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.TutorialCode.GDghostObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDPlayerObjects2Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDghostObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Cooldown") >= 0.5;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Sanity_Bar"), gdjs.TutorialCode.GDSanity_9595BarObjects2);
{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects2[i].returnVariable(gdjs.TutorialCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)).sub(1);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDSanity_9595BarObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDSanity_9595BarObjects2[i].getBehavior("Animation").setAnimationIndex(gdjs.TutorialCode.GDSanity_9595BarObjects2[i].getBehavior("Animation").getAnimationIndex() + (1));
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Cooldown");
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 1, 0.1, 0.1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkRight" ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDPlayerObjects2[k] = gdjs.TutorialCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkLeft" ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDPlayerObjects2[k] = gdjs.TutorialCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() != "WalkLeft" ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDPlayerObjects2[k] = gdjs.TutorialCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("WalkLeft");
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects2[i].getBehavior("Animation").resumeAnimation();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").getCurrentSpeed() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDPlayerObjects2[k] = gdjs.TutorialCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkRight" ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDPlayerObjects2[k] = gdjs.TutorialCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects2[i].resetTimer("Idle");
}
}{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").getCurrentSpeed() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDPlayerObjects2[k] = gdjs.TutorialCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkLeft" ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDPlayerObjects2[k] = gdjs.TutorialCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects2[i].resetTimer("Idle");
}
}{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("IdleLeft");
}
}}

}


{

gdjs.TutorialCode.GDPlayerObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "RShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.TutorialCode.GDPlayerObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects3);
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDPlayerObjects3[i].getBehavior("Animation").getAnimationName() == "WalkRight" ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDPlayerObjects3[k] = gdjs.TutorialCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDPlayerObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TutorialCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.TutorialCode.GDPlayerObjects2_1final.indexOf(gdjs.TutorialCode.GDPlayerObjects3[j]) === -1 )
            gdjs.TutorialCode.GDPlayerObjects2_1final.push(gdjs.TutorialCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects3);
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDPlayerObjects3[i].getBehavior("Animation").getAnimationName() == "Idle" ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDPlayerObjects3[k] = gdjs.TutorialCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDPlayerObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TutorialCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.TutorialCode.GDPlayerObjects2_1final.indexOf(gdjs.TutorialCode.GDPlayerObjects3[j]) === -1 )
            gdjs.TutorialCode.GDPlayerObjects2_1final.push(gdjs.TutorialCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TutorialCode.GDPlayerObjects2_1final, gdjs.TutorialCode.GDPlayerObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDPlayerObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Dash") >= 1 ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDPlayerObjects2[k] = gdjs.TutorialCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDPlayerObjects2.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects2[i].resetTimer("Dash");
}
}{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects2[i].addForce(1200, 0, 1);
}
}
{ //Subevents
gdjs.TutorialCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.TutorialCode.GDPlayerObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "RShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.TutorialCode.GDPlayerObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects3);
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDPlayerObjects3[i].getBehavior("Animation").getAnimationName() == "WalkLeft" ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDPlayerObjects3[k] = gdjs.TutorialCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDPlayerObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TutorialCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.TutorialCode.GDPlayerObjects2_1final.indexOf(gdjs.TutorialCode.GDPlayerObjects3[j]) === -1 )
            gdjs.TutorialCode.GDPlayerObjects2_1final.push(gdjs.TutorialCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TutorialCode.GDPlayerObjects2_1final, gdjs.TutorialCode.GDPlayerObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDPlayerObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Dash") >= 1 ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDPlayerObjects2[k] = gdjs.TutorialCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDPlayerObjects2.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects2[i].resetTimer("Dash");
}
}{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects2[i].addForce(-(1200), 0, 1);
}
}
{ //Subevents
gdjs.TutorialCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects1[i].resetTimer("Dash");
}
}}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDghostObjects2Objects = Hashtable.newFrom({"ghost": gdjs.TutorialCode.GDghostObjects2});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDGhost1LeftObjects2Objects = Hashtable.newFrom({"Ghost1Left": gdjs.TutorialCode.GDGhost1LeftObjects2});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDghostObjects1Objects = Hashtable.newFrom({"ghost": gdjs.TutorialCode.GDghostObjects1});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDGhost1RightObjects1Objects = Hashtable.newFrom({"Ghost1Right": gdjs.TutorialCode.GDGhost1RightObjects1});
gdjs.TutorialCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Ghost1Left"), gdjs.TutorialCode.GDGhost1LeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("Ghost1Right"), gdjs.TutorialCode.GDGhost1RightObjects2);
{for(var i = 0, len = gdjs.TutorialCode.GDGhost1RightObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDGhost1RightObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.TutorialCode.GDGhost1LeftObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDGhost1LeftObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ghost1Right"), gdjs.TutorialCode.GDGhost1RightObjects2);
gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.TutorialCode.GDghostObjects2);
{for(var i = 0, len = gdjs.TutorialCode.GDghostObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDghostObjects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.TutorialCode.GDGhost1RightObjects2.length === 0 ) ? 0 :gdjs.TutorialCode.GDGhost1RightObjects2[0].getPointX("")), (( gdjs.TutorialCode.GDGhost1RightObjects2.length === 0 ) ? 0 :gdjs.TutorialCode.GDGhost1RightObjects2[0].getPointY("")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost1Left"), gdjs.TutorialCode.GDGhost1LeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.TutorialCode.GDghostObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDghostObjects2Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDGhost1LeftObjects2Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ghost1Right"), gdjs.TutorialCode.GDGhost1RightObjects2);
/* Reuse gdjs.TutorialCode.GDghostObjects2 */
{for(var i = 0, len = gdjs.TutorialCode.GDghostObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDghostObjects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.TutorialCode.GDGhost1RightObjects2.length === 0 ) ? 0 :gdjs.TutorialCode.GDGhost1RightObjects2[0].getPointX("")), (( gdjs.TutorialCode.GDGhost1RightObjects2.length === 0 ) ? 0 :gdjs.TutorialCode.GDGhost1RightObjects2[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.TutorialCode.GDghostObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDghostObjects2[i].getBehavior("Animation").setAnimationIndex(gdjs.TutorialCode.GDghostObjects2[i].getBehavior("Animation").getAnimationIndex() - (1));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost1Right"), gdjs.TutorialCode.GDGhost1RightObjects1);
gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.TutorialCode.GDghostObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDghostObjects1Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDGhost1RightObjects1Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ghost1Left"), gdjs.TutorialCode.GDGhost1LeftObjects1);
/* Reuse gdjs.TutorialCode.GDghostObjects1 */
{for(var i = 0, len = gdjs.TutorialCode.GDghostObjects1.length ;i < len;++i) {
    gdjs.TutorialCode.GDghostObjects1[i].getBehavior("Animation").setAnimationName("Left");
}
}{for(var i = 0, len = gdjs.TutorialCode.GDghostObjects1.length ;i < len;++i) {
    gdjs.TutorialCode.GDghostObjects1[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.TutorialCode.GDGhost1LeftObjects1.length === 0 ) ? 0 :gdjs.TutorialCode.GDGhost1LeftObjects1[0].getPointX("")), (( gdjs.TutorialCode.GDGhost1LeftObjects1.length === 0 ) ? 0 :gdjs.TutorialCode.GDGhost1LeftObjects1[0].getPointY("")));
}
}}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.TutorialCode.GDPlayerObjects2});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.TutorialCode.GDCoinObjects2});
gdjs.TutorialCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "game music (important).mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.TutorialCode.GDCoinObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDPlayerObjects2Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCoinObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCoinObjects2 */
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.TutorialCode.GDCoinObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDCoinObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.TutorialCode.GDNewTextObjects2);
{for(var i = 0, len = gdjs.TutorialCode.GDNewTextObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDNewTextObjects2[i].getBehavior("Text").setText("= " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0))));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Cooldown");
}}

}


};gdjs.TutorialCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects1);
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.TutorialCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.TutorialCode.GDPlayerObjects1[0].getPointX("")), "", 0);
}}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDDetector_95959595tm_95959595Objects2Objects = Hashtable.newFrom({"Detector_tm_": gdjs.TutorialCode.GDDetector_9595tm_9595Objects2});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.TutorialCode.GDPlayerObjects2});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TutorialCode.GDPlayerObjects1});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDSkeletonObjects1Objects = Hashtable.newFrom({"Skeleton": gdjs.TutorialCode.GDSkeletonObjects1});
gdjs.TutorialCode.asyncCallback16052700 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Skeleton"), gdjs.TutorialCode.GDSkeletonObjects4);

{for(var i = 0, len = gdjs.TutorialCode.GDSkeletonObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDSkeletonObjects4[i].getBehavior("Resizable").setHeight(gdjs.TutorialCode.GDSkeletonObjects4[i].getBehavior("Resizable").getHeight() - (60));
}
}}
gdjs.TutorialCode.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.TutorialCode.GDSkeletonObjects3) asyncObjectsList.addObject("Skeleton", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.TutorialCode.asyncCallback16052700(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback16051996 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Skeleton"), gdjs.TutorialCode.GDSkeletonObjects3);

{for(var i = 0, len = gdjs.TutorialCode.GDSkeletonObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDSkeletonObjects3[i].getBehavior("Resizable").setHeight(gdjs.TutorialCode.GDSkeletonObjects3[i].getBehavior("Resizable").getHeight() - (60));
}
}
{ //Subevents
gdjs.TutorialCode.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.TutorialCode.eventsList7 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.TutorialCode.GDSkeletonObjects2) asyncObjectsList.addObject("Skeleton", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.TutorialCode.asyncCallback16051996(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TutorialCode.GDPlayerObjects1, gdjs.TutorialCode.GDPlayerObjects2);

gdjs.copyArray(gdjs.TutorialCode.GDSkeletonObjects1, gdjs.TutorialCode.GDSkeletonObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.TutorialCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.TutorialCode.GDPlayerObjects2[0].getPointY("Feet")) <= (( gdjs.TutorialCode.GDSkeletonObjects2.length === 0 ) ? 0 :gdjs.TutorialCode.GDSkeletonObjects2[0].getPointY("Head")));
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDSkeletonObjects2 */
{for(var i = 0, len = gdjs.TutorialCode.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDSkeletonObjects2[i].getBehavior("Resizable").setHeight(gdjs.TutorialCode.GDSkeletonObjects2[i].getBehavior("Resizable").getHeight() - (60));
}
}
{ //Subevents
gdjs.TutorialCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.TutorialCode.GDPlayerObjects1 */
/* Reuse gdjs.TutorialCode.GDSkeletonObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.TutorialCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.TutorialCode.GDPlayerObjects1[0].getPointY("Feet")) > (( gdjs.TutorialCode.GDSkeletonObjects1.length === 0 ) ? 0 :gdjs.TutorialCode.GDSkeletonObjects1[0].getPointY("Head")));
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Cooldown") >= 0.5;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDPlayerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Sanity_Bar"), gdjs.TutorialCode.GDSanity_9595BarObjects1);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Cooldown");
}{for(var i = 0, len = gdjs.TutorialCode.GDSanity_9595BarObjects1.length ;i < len;++i) {
    gdjs.TutorialCode.GDSanity_9595BarObjects1[i].getBehavior("Animation").setAnimationIndex(gdjs.TutorialCode.GDSanity_9595BarObjects1[i].getBehavior("Animation").getAnimationIndex() + (1));
}
}{for(var i = 0, len = gdjs.TutorialCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TutorialCode.GDPlayerObjects1[i].returnVariable(gdjs.TutorialCode.GDPlayerObjects1[i].getVariables().getFromIndex(0)).sub(1);
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 1, 0.1, 0.1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.TutorialCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.TutorialCode.GDSkeletonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDSkeletonObjects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDSkeletonObjects2[i].getX() < (( gdjs.TutorialCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.TutorialCode.GDPlayerObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDSkeletonObjects2[k] = gdjs.TutorialCode.GDSkeletonObjects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDSkeletonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDSkeletonObjects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDSkeletonObjects2[i].getVariableBoolean(gdjs.TutorialCode.GDSkeletonObjects2[i].getVariables().getFromIndex(0), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDSkeletonObjects2[k] = gdjs.TutorialCode.GDSkeletonObjects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDSkeletonObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDSkeletonObjects2 */
{for(var i = 0, len = gdjs.TutorialCode.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDSkeletonObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.TutorialCode.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDSkeletonObjects2[i].getBehavior("Animation").setAnimationName("Walking Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.TutorialCode.GDSkeletonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDSkeletonObjects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDSkeletonObjects2[i].getX() > (( gdjs.TutorialCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.TutorialCode.GDPlayerObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDSkeletonObjects2[k] = gdjs.TutorialCode.GDSkeletonObjects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDSkeletonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDSkeletonObjects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDSkeletonObjects2[i].getVariableBoolean(gdjs.TutorialCode.GDSkeletonObjects2[i].getVariables().getFromIndex(0), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDSkeletonObjects2[k] = gdjs.TutorialCode.GDSkeletonObjects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDSkeletonObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDSkeletonObjects2 */
{for(var i = 0, len = gdjs.TutorialCode.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDSkeletonObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{for(var i = 0, len = gdjs.TutorialCode.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDSkeletonObjects2[i].getBehavior("Animation").setAnimationName("Walking Left");
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.TutorialCode.GDSkeletonObjects2);
{for(var i = 0, len = gdjs.TutorialCode.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDSkeletonObjects2[i].getBehavior("PlatformerObject").ignoreDefaultControls(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Detector_tm_"), gdjs.TutorialCode.GDDetector_9595tm_9595Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDDetector_95959595tm_95959595Objects2Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.TutorialCode.GDSkeletonObjects2);
{for(var i = 0, len = gdjs.TutorialCode.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDSkeletonObjects2[i].setVariableBoolean(gdjs.TutorialCode.GDSkeletonObjects2[i].getVariables().getFromIndex(0), true);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Detector_tm_"), gdjs.TutorialCode.GDDetector_9595tm_9595Objects2);
{for(var i = 0, len = gdjs.TutorialCode.GDDetector_9595tm_9595Objects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDDetector_9595tm_9595Objects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.TutorialCode.GDSkeletonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDPlayerObjects1Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDSkeletonObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TutorialCode.GDPlayerObjects1});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDbedObjects1Objects = Hashtable.newFrom({"bed": gdjs.TutorialCode.GDbedObjects1});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.TutorialCode.GDPlayerObjects2});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDBottomObjects2Objects = Hashtable.newFrom({"Bottom": gdjs.TutorialCode.GDBottomObjects2});
gdjs.TutorialCode.eventsList10 = function(runtimeScene) {

{


gdjs.TutorialCode.eventsList2(runtimeScene);
}


{


gdjs.TutorialCode.eventsList3(runtimeScene);
}


{


gdjs.TutorialCode.eventsList4(runtimeScene);
}


{


gdjs.TutorialCode.eventsList5(runtimeScene);
}


{


gdjs.TutorialCode.eventsList9(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("bed"), gdjs.TutorialCode.GDbedObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDPlayerObjects1Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDbedObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level1", false);
}}

}


{

gdjs.TutorialCode.GDBottomObjects1.length = 0;

gdjs.TutorialCode.GDPlayerObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.TutorialCode.GDBottomObjects1_1final.length = 0;
gdjs.TutorialCode.GDPlayerObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bottom"), gdjs.TutorialCode.GDBottomObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDPlayerObjects2Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDBottomObjects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TutorialCode.GDBottomObjects2.length; j < jLen ; ++j) {
        if ( gdjs.TutorialCode.GDBottomObjects1_1final.indexOf(gdjs.TutorialCode.GDBottomObjects2[j]) === -1 )
            gdjs.TutorialCode.GDBottomObjects1_1final.push(gdjs.TutorialCode.GDBottomObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.TutorialCode.GDPlayerObjects2.length; j < jLen ; ++j) {
        if ( gdjs.TutorialCode.GDPlayerObjects1_1final.indexOf(gdjs.TutorialCode.GDPlayerObjects2[j]) === -1 )
            gdjs.TutorialCode.GDPlayerObjects1_1final.push(gdjs.TutorialCode.GDPlayerObjects2[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "r");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.TutorialCode.GDBottomObjects1_1final, gdjs.TutorialCode.GDBottomObjects1);
gdjs.copyArray(gdjs.TutorialCode.GDPlayerObjects1_1final, gdjs.TutorialCode.GDPlayerObjects1);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TutorialCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDPlayerObjects1[i].getVariableNumber(gdjs.TutorialCode.GDPlayerObjects1[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDPlayerObjects1[k] = gdjs.TutorialCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.TutorialCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


};

gdjs.TutorialCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.TutorialCode.GDPlatformObjects1.length = 0;
gdjs.TutorialCode.GDPlatformObjects2.length = 0;
gdjs.TutorialCode.GDPlatformObjects3.length = 0;
gdjs.TutorialCode.GDPlatformObjects4.length = 0;
gdjs.TutorialCode.GDghostObjects1.length = 0;
gdjs.TutorialCode.GDghostObjects2.length = 0;
gdjs.TutorialCode.GDghostObjects3.length = 0;
gdjs.TutorialCode.GDghostObjects4.length = 0;
gdjs.TutorialCode.GDGhost1RightObjects1.length = 0;
gdjs.TutorialCode.GDGhost1RightObjects2.length = 0;
gdjs.TutorialCode.GDGhost1RightObjects3.length = 0;
gdjs.TutorialCode.GDGhost1RightObjects4.length = 0;
gdjs.TutorialCode.GDGhost1LeftObjects1.length = 0;
gdjs.TutorialCode.GDGhost1LeftObjects2.length = 0;
gdjs.TutorialCode.GDGhost1LeftObjects3.length = 0;
gdjs.TutorialCode.GDGhost1LeftObjects4.length = 0;
gdjs.TutorialCode.GDPlatform2Objects1.length = 0;
gdjs.TutorialCode.GDPlatform2Objects2.length = 0;
gdjs.TutorialCode.GDPlatform2Objects3.length = 0;
gdjs.TutorialCode.GDPlatform2Objects4.length = 0;
gdjs.TutorialCode.GDCoinObjects1.length = 0;
gdjs.TutorialCode.GDCoinObjects2.length = 0;
gdjs.TutorialCode.GDCoinObjects3.length = 0;
gdjs.TutorialCode.GDCoinObjects4.length = 0;
gdjs.TutorialCode.GDNewTextObjects1.length = 0;
gdjs.TutorialCode.GDNewTextObjects2.length = 0;
gdjs.TutorialCode.GDNewTextObjects3.length = 0;
gdjs.TutorialCode.GDNewTextObjects4.length = 0;
gdjs.TutorialCode.GDNewText2Objects1.length = 0;
gdjs.TutorialCode.GDNewText2Objects2.length = 0;
gdjs.TutorialCode.GDNewText2Objects3.length = 0;
gdjs.TutorialCode.GDNewText2Objects4.length = 0;
gdjs.TutorialCode.GDNewSpriteObjects1.length = 0;
gdjs.TutorialCode.GDNewSpriteObjects2.length = 0;
gdjs.TutorialCode.GDNewSpriteObjects3.length = 0;
gdjs.TutorialCode.GDNewSpriteObjects4.length = 0;
gdjs.TutorialCode.GDWallObjects1.length = 0;
gdjs.TutorialCode.GDWallObjects2.length = 0;
gdjs.TutorialCode.GDWallObjects3.length = 0;
gdjs.TutorialCode.GDWallObjects4.length = 0;
gdjs.TutorialCode.GDMovingfrfrfObjects1.length = 0;
gdjs.TutorialCode.GDMovingfrfrfObjects2.length = 0;
gdjs.TutorialCode.GDMovingfrfrfObjects3.length = 0;
gdjs.TutorialCode.GDMovingfrfrfObjects4.length = 0;
gdjs.TutorialCode.GDdashObjects1.length = 0;
gdjs.TutorialCode.GDdashObjects2.length = 0;
gdjs.TutorialCode.GDdashObjects3.length = 0;
gdjs.TutorialCode.GDdashObjects4.length = 0;
gdjs.TutorialCode.GDjumpghostObjects1.length = 0;
gdjs.TutorialCode.GDjumpghostObjects2.length = 0;
gdjs.TutorialCode.GDjumpghostObjects3.length = 0;
gdjs.TutorialCode.GDjumpghostObjects4.length = 0;
gdjs.TutorialCode.GDhitskeleObjects1.length = 0;
gdjs.TutorialCode.GDhitskeleObjects2.length = 0;
gdjs.TutorialCode.GDhitskeleObjects3.length = 0;
gdjs.TutorialCode.GDhitskeleObjects4.length = 0;
gdjs.TutorialCode.GDDetector_9595tm_9595Objects1.length = 0;
gdjs.TutorialCode.GDDetector_9595tm_9595Objects2.length = 0;
gdjs.TutorialCode.GDDetector_9595tm_9595Objects3.length = 0;
gdjs.TutorialCode.GDDetector_9595tm_9595Objects4.length = 0;
gdjs.TutorialCode.GDbedObjects1.length = 0;
gdjs.TutorialCode.GDbedObjects2.length = 0;
gdjs.TutorialCode.GDbedObjects3.length = 0;
gdjs.TutorialCode.GDbedObjects4.length = 0;
gdjs.TutorialCode.GDBedWinObjects1.length = 0;
gdjs.TutorialCode.GDBedWinObjects2.length = 0;
gdjs.TutorialCode.GDBedWinObjects3.length = 0;
gdjs.TutorialCode.GDBedWinObjects4.length = 0;
gdjs.TutorialCode.GDBackgroundObjects1.length = 0;
gdjs.TutorialCode.GDBackgroundObjects2.length = 0;
gdjs.TutorialCode.GDBackgroundObjects3.length = 0;
gdjs.TutorialCode.GDBackgroundObjects4.length = 0;
gdjs.TutorialCode.GDSkeletonObjects1.length = 0;
gdjs.TutorialCode.GDSkeletonObjects2.length = 0;
gdjs.TutorialCode.GDSkeletonObjects3.length = 0;
gdjs.TutorialCode.GDSkeletonObjects4.length = 0;
gdjs.TutorialCode.GDSanity_9595BarObjects1.length = 0;
gdjs.TutorialCode.GDSanity_9595BarObjects2.length = 0;
gdjs.TutorialCode.GDSanity_9595BarObjects3.length = 0;
gdjs.TutorialCode.GDSanity_9595BarObjects4.length = 0;
gdjs.TutorialCode.GDPlayerObjects1.length = 0;
gdjs.TutorialCode.GDPlayerObjects2.length = 0;
gdjs.TutorialCode.GDPlayerObjects3.length = 0;
gdjs.TutorialCode.GDPlayerObjects4.length = 0;
gdjs.TutorialCode.GDBottomObjects1.length = 0;
gdjs.TutorialCode.GDBottomObjects2.length = 0;
gdjs.TutorialCode.GDBottomObjects3.length = 0;
gdjs.TutorialCode.GDBottomObjects4.length = 0;

gdjs.TutorialCode.eventsList10(runtimeScene);

return;

}

gdjs['TutorialCode'] = gdjs.TutorialCode;
