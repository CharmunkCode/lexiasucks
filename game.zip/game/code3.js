gdjs.TemplateCode = {};
gdjs.TemplateCode.GDPlayerObjects2_1final = [];

gdjs.TemplateCode.GDPlatformObjects1= [];
gdjs.TemplateCode.GDPlatformObjects2= [];
gdjs.TemplateCode.GDPlatformObjects3= [];
gdjs.TemplateCode.GDPlatformObjects4= [];
gdjs.TemplateCode.GDPlayerObjects1= [];
gdjs.TemplateCode.GDPlayerObjects2= [];
gdjs.TemplateCode.GDPlayerObjects3= [];
gdjs.TemplateCode.GDPlayerObjects4= [];
gdjs.TemplateCode.GDghostObjects1= [];
gdjs.TemplateCode.GDghostObjects2= [];
gdjs.TemplateCode.GDghostObjects3= [];
gdjs.TemplateCode.GDghostObjects4= [];
gdjs.TemplateCode.GDGhost1RightObjects1= [];
gdjs.TemplateCode.GDGhost1RightObjects2= [];
gdjs.TemplateCode.GDGhost1RightObjects3= [];
gdjs.TemplateCode.GDGhost1RightObjects4= [];
gdjs.TemplateCode.GDGhost1LeftObjects1= [];
gdjs.TemplateCode.GDGhost1LeftObjects2= [];
gdjs.TemplateCode.GDGhost1LeftObjects3= [];
gdjs.TemplateCode.GDGhost1LeftObjects4= [];
gdjs.TemplateCode.GDPlatform2Objects1= [];
gdjs.TemplateCode.GDPlatform2Objects2= [];
gdjs.TemplateCode.GDPlatform2Objects3= [];
gdjs.TemplateCode.GDPlatform2Objects4= [];
gdjs.TemplateCode.GDCoinObjects1= [];
gdjs.TemplateCode.GDCoinObjects2= [];
gdjs.TemplateCode.GDCoinObjects3= [];
gdjs.TemplateCode.GDCoinObjects4= [];
gdjs.TemplateCode.GDNewTextObjects1= [];
gdjs.TemplateCode.GDNewTextObjects2= [];
gdjs.TemplateCode.GDNewTextObjects3= [];
gdjs.TemplateCode.GDNewTextObjects4= [];
gdjs.TemplateCode.GDNewText2Objects1= [];
gdjs.TemplateCode.GDNewText2Objects2= [];
gdjs.TemplateCode.GDNewText2Objects3= [];
gdjs.TemplateCode.GDNewText2Objects4= [];
gdjs.TemplateCode.GDNewSpriteObjects1= [];
gdjs.TemplateCode.GDNewSpriteObjects2= [];
gdjs.TemplateCode.GDNewSpriteObjects3= [];
gdjs.TemplateCode.GDNewSpriteObjects4= [];
gdjs.TemplateCode.GDWallObjects1= [];
gdjs.TemplateCode.GDWallObjects2= [];
gdjs.TemplateCode.GDWallObjects3= [];
gdjs.TemplateCode.GDWallObjects4= [];
gdjs.TemplateCode.GDMovingfrfrfObjects1= [];
gdjs.TemplateCode.GDMovingfrfrfObjects2= [];
gdjs.TemplateCode.GDMovingfrfrfObjects3= [];
gdjs.TemplateCode.GDMovingfrfrfObjects4= [];
gdjs.TemplateCode.GDdashObjects1= [];
gdjs.TemplateCode.GDdashObjects2= [];
gdjs.TemplateCode.GDdashObjects3= [];
gdjs.TemplateCode.GDdashObjects4= [];
gdjs.TemplateCode.GDjumpghostObjects1= [];
gdjs.TemplateCode.GDjumpghostObjects2= [];
gdjs.TemplateCode.GDjumpghostObjects3= [];
gdjs.TemplateCode.GDjumpghostObjects4= [];
gdjs.TemplateCode.GDhitskeleObjects1= [];
gdjs.TemplateCode.GDhitskeleObjects2= [];
gdjs.TemplateCode.GDhitskeleObjects3= [];
gdjs.TemplateCode.GDhitskeleObjects4= [];
gdjs.TemplateCode.GDDetector_9595tm_9595Objects1= [];
gdjs.TemplateCode.GDDetector_9595tm_9595Objects2= [];
gdjs.TemplateCode.GDDetector_9595tm_9595Objects3= [];
gdjs.TemplateCode.GDDetector_9595tm_9595Objects4= [];
gdjs.TemplateCode.GDbedObjects1= [];
gdjs.TemplateCode.GDbedObjects2= [];
gdjs.TemplateCode.GDbedObjects3= [];
gdjs.TemplateCode.GDbedObjects4= [];
gdjs.TemplateCode.GDBedWinObjects1= [];
gdjs.TemplateCode.GDBedWinObjects2= [];
gdjs.TemplateCode.GDBedWinObjects3= [];
gdjs.TemplateCode.GDBedWinObjects4= [];
gdjs.TemplateCode.GDBackgroundObjects1= [];
gdjs.TemplateCode.GDBackgroundObjects2= [];
gdjs.TemplateCode.GDBackgroundObjects3= [];
gdjs.TemplateCode.GDBackgroundObjects4= [];
gdjs.TemplateCode.GDSkeletonObjects1= [];
gdjs.TemplateCode.GDSkeletonObjects2= [];
gdjs.TemplateCode.GDSkeletonObjects3= [];
gdjs.TemplateCode.GDSkeletonObjects4= [];
gdjs.TemplateCode.GDSanity_9595BarObjects1= [];
gdjs.TemplateCode.GDSanity_9595BarObjects2= [];
gdjs.TemplateCode.GDSanity_9595BarObjects3= [];
gdjs.TemplateCode.GDSanity_9595BarObjects4= [];
gdjs.TemplateCode.GDPlayerObjects1= [];
gdjs.TemplateCode.GDPlayerObjects2= [];
gdjs.TemplateCode.GDPlayerObjects3= [];
gdjs.TemplateCode.GDPlayerObjects4= [];
gdjs.TemplateCode.GDBottomObjects1= [];
gdjs.TemplateCode.GDBottomObjects2= [];
gdjs.TemplateCode.GDBottomObjects3= [];
gdjs.TemplateCode.GDBottomObjects4= [];


gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.TemplateCode.GDPlayerObjects2});
gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDghostObjects2Objects = Hashtable.newFrom({"ghost": gdjs.TemplateCode.GDghostObjects2});
gdjs.TemplateCode.asyncCallback16133388 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.TemplateCode.GDPlayerObjects3);

{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects3[i].getBehavior("PlatformerObject").setCanNotAirJump();
}
}}
gdjs.TemplateCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.TemplateCode.GDPlayerObjects2) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.15), (runtimeScene) => (gdjs.TemplateCode.asyncCallback16133388(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TemplateCode.asyncCallback16137060 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.TemplateCode.GDPlayerObjects3);

{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects3[i].getBehavior("PlatformerObject").setCanNotAirJump();
}
}}
gdjs.TemplateCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.TemplateCode.GDPlayerObjects2) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.15), (runtimeScene) => (gdjs.TemplateCode.asyncCallback16137060(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TemplateCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TemplateCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TemplateCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TemplateCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.TemplateCode.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() != "WalkRight" ) {
        isConditionTrue_0 = true;
        gdjs.TemplateCode.GDPlayerObjects2[k] = gdjs.TemplateCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.TemplateCode.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TemplateCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationIndex(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TemplateCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TemplateCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.TemplateCode.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkRight" ) {
        isConditionTrue_0 = true;
        gdjs.TemplateCode.GDPlayerObjects2[k] = gdjs.TemplateCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.TemplateCode.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TemplateCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TemplateCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.TemplateCode.GDghostObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDPlayerObjects2Objects, gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDghostObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TemplateCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level Template", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TemplateCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TemplateCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.TemplateCode.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkRight" ) {
        isConditionTrue_0 = true;
        gdjs.TemplateCode.GDPlayerObjects2[k] = gdjs.TemplateCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.TemplateCode.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TemplateCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TemplateCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TemplateCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.TemplateCode.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkLeft" ) {
        isConditionTrue_0 = true;
        gdjs.TemplateCode.GDPlayerObjects2[k] = gdjs.TemplateCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.TemplateCode.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TemplateCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TemplateCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TemplateCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.TemplateCode.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() != "WalkLeft" ) {
        isConditionTrue_0 = true;
        gdjs.TemplateCode.GDPlayerObjects2[k] = gdjs.TemplateCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.TemplateCode.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TemplateCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("WalkLeft");
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TemplateCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects2[i].getBehavior("Animation").resumeAnimation();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TemplateCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TemplateCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.TemplateCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").getCurrentSpeed() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.TemplateCode.GDPlayerObjects2[k] = gdjs.TemplateCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.TemplateCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TemplateCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.TemplateCode.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkRight" ) {
        isConditionTrue_0 = true;
        gdjs.TemplateCode.GDPlayerObjects2[k] = gdjs.TemplateCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.TemplateCode.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TemplateCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects2[i].resetTimer("Idle");
}
}{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TemplateCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TemplateCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.TemplateCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").getCurrentSpeed() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.TemplateCode.GDPlayerObjects2[k] = gdjs.TemplateCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.TemplateCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TemplateCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.TemplateCode.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkLeft" ) {
        isConditionTrue_0 = true;
        gdjs.TemplateCode.GDPlayerObjects2[k] = gdjs.TemplateCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.TemplateCode.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TemplateCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects2[i].resetTimer("Idle");
}
}{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("IdleLeft");
}
}}

}


{

gdjs.TemplateCode.GDPlayerObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "RShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.TemplateCode.GDPlayerObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TemplateCode.GDPlayerObjects3);
for (var i = 0, k = 0, l = gdjs.TemplateCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.TemplateCode.GDPlayerObjects3[i].getBehavior("Animation").getAnimationName() == "WalkRight" ) {
        isConditionTrue_1 = true;
        gdjs.TemplateCode.GDPlayerObjects3[k] = gdjs.TemplateCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.TemplateCode.GDPlayerObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TemplateCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.TemplateCode.GDPlayerObjects2_1final.indexOf(gdjs.TemplateCode.GDPlayerObjects3[j]) === -1 )
            gdjs.TemplateCode.GDPlayerObjects2_1final.push(gdjs.TemplateCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TemplateCode.GDPlayerObjects3);
for (var i = 0, k = 0, l = gdjs.TemplateCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.TemplateCode.GDPlayerObjects3[i].getBehavior("Animation").getAnimationName() == "Idle" ) {
        isConditionTrue_1 = true;
        gdjs.TemplateCode.GDPlayerObjects3[k] = gdjs.TemplateCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.TemplateCode.GDPlayerObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TemplateCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.TemplateCode.GDPlayerObjects2_1final.indexOf(gdjs.TemplateCode.GDPlayerObjects3[j]) === -1 )
            gdjs.TemplateCode.GDPlayerObjects2_1final.push(gdjs.TemplateCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TemplateCode.GDPlayerObjects2_1final, gdjs.TemplateCode.GDPlayerObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TemplateCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.TemplateCode.GDPlayerObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Dash") >= 1 ) {
        isConditionTrue_0 = true;
        gdjs.TemplateCode.GDPlayerObjects2[k] = gdjs.TemplateCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.TemplateCode.GDPlayerObjects2.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TemplateCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects2[i].resetTimer("Dash");
}
}{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects2[i].addForce(1200, 0, 1);
}
}
{ //Subevents
gdjs.TemplateCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.TemplateCode.GDPlayerObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "RShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.TemplateCode.GDPlayerObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TemplateCode.GDPlayerObjects3);
for (var i = 0, k = 0, l = gdjs.TemplateCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.TemplateCode.GDPlayerObjects3[i].getBehavior("Animation").getAnimationName() == "WalkLeft" ) {
        isConditionTrue_1 = true;
        gdjs.TemplateCode.GDPlayerObjects3[k] = gdjs.TemplateCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.TemplateCode.GDPlayerObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TemplateCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.TemplateCode.GDPlayerObjects2_1final.indexOf(gdjs.TemplateCode.GDPlayerObjects3[j]) === -1 )
            gdjs.TemplateCode.GDPlayerObjects2_1final.push(gdjs.TemplateCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TemplateCode.GDPlayerObjects2_1final, gdjs.TemplateCode.GDPlayerObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TemplateCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.TemplateCode.GDPlayerObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Dash") >= 1 ) {
        isConditionTrue_0 = true;
        gdjs.TemplateCode.GDPlayerObjects2[k] = gdjs.TemplateCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.TemplateCode.GDPlayerObjects2.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TemplateCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects2[i].resetTimer("Dash");
}
}{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects2[i].addForce(-(1200), 0, 1);
}
}
{ //Subevents
gdjs.TemplateCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TemplateCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects1[i].resetTimer("Dash");
}
}}

}


};gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDghostObjects2Objects = Hashtable.newFrom({"ghost": gdjs.TemplateCode.GDghostObjects2});
gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDGhost1LeftObjects2Objects = Hashtable.newFrom({"Ghost1Left": gdjs.TemplateCode.GDGhost1LeftObjects2});
gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDghostObjects1Objects = Hashtable.newFrom({"ghost": gdjs.TemplateCode.GDghostObjects1});
gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDGhost1RightObjects1Objects = Hashtable.newFrom({"Ghost1Right": gdjs.TemplateCode.GDGhost1RightObjects1});
gdjs.TemplateCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Ghost1Left"), gdjs.TemplateCode.GDGhost1LeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("Ghost1Right"), gdjs.TemplateCode.GDGhost1RightObjects2);
{for(var i = 0, len = gdjs.TemplateCode.GDGhost1RightObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDGhost1RightObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.TemplateCode.GDGhost1LeftObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDGhost1LeftObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ghost1Right"), gdjs.TemplateCode.GDGhost1RightObjects2);
gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.TemplateCode.GDghostObjects2);
{for(var i = 0, len = gdjs.TemplateCode.GDghostObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDghostObjects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.TemplateCode.GDGhost1RightObjects2.length === 0 ) ? 0 :gdjs.TemplateCode.GDGhost1RightObjects2[0].getPointX("")), (( gdjs.TemplateCode.GDGhost1RightObjects2.length === 0 ) ? 0 :gdjs.TemplateCode.GDGhost1RightObjects2[0].getPointY("")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost1Left"), gdjs.TemplateCode.GDGhost1LeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.TemplateCode.GDghostObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDghostObjects2Objects, gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDGhost1LeftObjects2Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ghost1Right"), gdjs.TemplateCode.GDGhost1RightObjects2);
/* Reuse gdjs.TemplateCode.GDghostObjects2 */
{for(var i = 0, len = gdjs.TemplateCode.GDghostObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDghostObjects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.TemplateCode.GDGhost1RightObjects2.length === 0 ) ? 0 :gdjs.TemplateCode.GDGhost1RightObjects2[0].getPointX("")), (( gdjs.TemplateCode.GDGhost1RightObjects2.length === 0 ) ? 0 :gdjs.TemplateCode.GDGhost1RightObjects2[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.TemplateCode.GDghostObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDghostObjects2[i].getBehavior("Animation").setAnimationIndex(gdjs.TemplateCode.GDghostObjects2[i].getBehavior("Animation").getAnimationIndex() - (1));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost1Right"), gdjs.TemplateCode.GDGhost1RightObjects1);
gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.TemplateCode.GDghostObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDghostObjects1Objects, gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDGhost1RightObjects1Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ghost1Left"), gdjs.TemplateCode.GDGhost1LeftObjects1);
/* Reuse gdjs.TemplateCode.GDghostObjects1 */
{for(var i = 0, len = gdjs.TemplateCode.GDghostObjects1.length ;i < len;++i) {
    gdjs.TemplateCode.GDghostObjects1[i].getBehavior("Animation").setAnimationName("Left");
}
}{for(var i = 0, len = gdjs.TemplateCode.GDghostObjects1.length ;i < len;++i) {
    gdjs.TemplateCode.GDghostObjects1[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.TemplateCode.GDGhost1LeftObjects1.length === 0 ) ? 0 :gdjs.TemplateCode.GDGhost1LeftObjects1[0].getPointX("")), (( gdjs.TemplateCode.GDGhost1LeftObjects1.length === 0 ) ? 0 :gdjs.TemplateCode.GDGhost1LeftObjects1[0].getPointY("")));
}
}}

}


};gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.TemplateCode.GDPlayerObjects2});
gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.TemplateCode.GDCoinObjects2});
gdjs.TemplateCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "game music (important).mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.TemplateCode.GDCoinObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TemplateCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDPlayerObjects2Objects, gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDCoinObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TemplateCode.GDCoinObjects2 */
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.TemplateCode.GDCoinObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDCoinObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.TemplateCode.GDNewTextObjects1);
{for(var i = 0, len = gdjs.TemplateCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.TemplateCode.GDNewTextObjects1[i].getBehavior("Text").setText("= " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0))));
}
}}

}


};gdjs.TemplateCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TemplateCode.GDPlayerObjects1);
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.TemplateCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.TemplateCode.GDPlayerObjects1[0].getPointX("")), "", 0);
}}

}


};gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDDetector_95959595tm_95959595Objects2Objects = Hashtable.newFrom({"Detector_tm_": gdjs.TemplateCode.GDDetector_9595tm_9595Objects2});
gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.TemplateCode.GDPlayerObjects2});
gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TemplateCode.GDPlayerObjects1});
gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDSkeletonObjects1Objects = Hashtable.newFrom({"Skeleton": gdjs.TemplateCode.GDSkeletonObjects1});
gdjs.TemplateCode.asyncCallback16150580 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Skeleton"), gdjs.TemplateCode.GDSkeletonObjects4);

{for(var i = 0, len = gdjs.TemplateCode.GDSkeletonObjects4.length ;i < len;++i) {
    gdjs.TemplateCode.GDSkeletonObjects4[i].getBehavior("Resizable").setHeight(gdjs.TemplateCode.GDSkeletonObjects4[i].getBehavior("Resizable").getHeight() - (60));
}
}{for(var i = 0, len = gdjs.TemplateCode.GDSkeletonObjects4.length ;i < len;++i) {
    gdjs.TemplateCode.GDSkeletonObjects4[i].deleteFromScene(runtimeScene);
}
}}
gdjs.TemplateCode.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.TemplateCode.GDSkeletonObjects3) asyncObjectsList.addObject("Skeleton", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.TemplateCode.asyncCallback16150580(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TemplateCode.asyncCallback16149876 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Skeleton"), gdjs.TemplateCode.GDSkeletonObjects3);

{for(var i = 0, len = gdjs.TemplateCode.GDSkeletonObjects3.length ;i < len;++i) {
    gdjs.TemplateCode.GDSkeletonObjects3[i].getBehavior("Resizable").setHeight(gdjs.TemplateCode.GDSkeletonObjects3[i].getBehavior("Resizable").getHeight() - (60));
}
}
{ //Subevents
gdjs.TemplateCode.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.TemplateCode.eventsList7 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.TemplateCode.GDSkeletonObjects2) asyncObjectsList.addObject("Skeleton", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.TemplateCode.asyncCallback16149876(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TemplateCode.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TemplateCode.GDPlayerObjects1, gdjs.TemplateCode.GDPlayerObjects2);

gdjs.copyArray(gdjs.TemplateCode.GDSkeletonObjects1, gdjs.TemplateCode.GDSkeletonObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.TemplateCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.TemplateCode.GDPlayerObjects2[0].getPointY("Feet")) <= (( gdjs.TemplateCode.GDSkeletonObjects2.length === 0 ) ? 0 :gdjs.TemplateCode.GDSkeletonObjects2[0].getPointY("Head")));
}
if (isConditionTrue_0) {
/* Reuse gdjs.TemplateCode.GDSkeletonObjects2 */
{for(var i = 0, len = gdjs.TemplateCode.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDSkeletonObjects2[i].getBehavior("Resizable").setHeight(gdjs.TemplateCode.GDSkeletonObjects2[i].getBehavior("Resizable").getHeight() - (60));
}
}
{ //Subevents
gdjs.TemplateCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.TemplateCode.GDPlayerObjects1 */
/* Reuse gdjs.TemplateCode.GDSkeletonObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.TemplateCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.TemplateCode.GDPlayerObjects1[0].getPointY("Feet")) > (( gdjs.TemplateCode.GDSkeletonObjects1.length === 0 ) ? 0 :gdjs.TemplateCode.GDSkeletonObjects1[0].getPointY("Head")));
}
if (isConditionTrue_0) {
/* Reuse gdjs.TemplateCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.TemplateCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.TemplateCode.GDPlayerObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.TemplateCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TemplateCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.TemplateCode.GDSkeletonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TemplateCode.GDSkeletonObjects2.length;i<l;++i) {
    if ( gdjs.TemplateCode.GDSkeletonObjects2[i].getX() < (( gdjs.TemplateCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.TemplateCode.GDPlayerObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.TemplateCode.GDSkeletonObjects2[k] = gdjs.TemplateCode.GDSkeletonObjects2[i];
        ++k;
    }
}
gdjs.TemplateCode.GDSkeletonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TemplateCode.GDSkeletonObjects2.length;i<l;++i) {
    if ( gdjs.TemplateCode.GDSkeletonObjects2[i].getVariableBoolean(gdjs.TemplateCode.GDSkeletonObjects2[i].getVariables().getFromIndex(0), true) ) {
        isConditionTrue_0 = true;
        gdjs.TemplateCode.GDSkeletonObjects2[k] = gdjs.TemplateCode.GDSkeletonObjects2[i];
        ++k;
    }
}
gdjs.TemplateCode.GDSkeletonObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TemplateCode.GDSkeletonObjects2 */
{for(var i = 0, len = gdjs.TemplateCode.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDSkeletonObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.TemplateCode.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDSkeletonObjects2[i].getBehavior("Animation").setAnimationName("Walking Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TemplateCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.TemplateCode.GDSkeletonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TemplateCode.GDSkeletonObjects2.length;i<l;++i) {
    if ( gdjs.TemplateCode.GDSkeletonObjects2[i].getX() > (( gdjs.TemplateCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.TemplateCode.GDPlayerObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.TemplateCode.GDSkeletonObjects2[k] = gdjs.TemplateCode.GDSkeletonObjects2[i];
        ++k;
    }
}
gdjs.TemplateCode.GDSkeletonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TemplateCode.GDSkeletonObjects2.length;i<l;++i) {
    if ( gdjs.TemplateCode.GDSkeletonObjects2[i].getVariableBoolean(gdjs.TemplateCode.GDSkeletonObjects2[i].getVariables().getFromIndex(0), true) ) {
        isConditionTrue_0 = true;
        gdjs.TemplateCode.GDSkeletonObjects2[k] = gdjs.TemplateCode.GDSkeletonObjects2[i];
        ++k;
    }
}
gdjs.TemplateCode.GDSkeletonObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TemplateCode.GDSkeletonObjects2 */
{for(var i = 0, len = gdjs.TemplateCode.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDSkeletonObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{for(var i = 0, len = gdjs.TemplateCode.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDSkeletonObjects2[i].getBehavior("Animation").setAnimationName("Walking Left");
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.TemplateCode.GDSkeletonObjects2);
{for(var i = 0, len = gdjs.TemplateCode.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDSkeletonObjects2[i].getBehavior("PlatformerObject").ignoreDefaultControls(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Detector_tm_"), gdjs.TemplateCode.GDDetector_9595tm_9595Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TemplateCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDDetector_95959595tm_95959595Objects2Objects, gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.TemplateCode.GDSkeletonObjects2);
{for(var i = 0, len = gdjs.TemplateCode.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDSkeletonObjects2[i].setVariableBoolean(gdjs.TemplateCode.GDSkeletonObjects2[i].getVariables().getFromIndex(0), true);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Detector_tm_"), gdjs.TemplateCode.GDDetector_9595tm_9595Objects2);
{for(var i = 0, len = gdjs.TemplateCode.GDDetector_9595tm_9595Objects2.length ;i < len;++i) {
    gdjs.TemplateCode.GDDetector_9595tm_9595Objects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TemplateCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.TemplateCode.GDSkeletonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDPlayerObjects1Objects, gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDSkeletonObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.TemplateCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.TemplateCode.GDPlayerObjects1});
gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDbedObjects1Objects = Hashtable.newFrom({"bed": gdjs.TemplateCode.GDbedObjects1});
gdjs.TemplateCode.eventsList10 = function(runtimeScene) {

{


gdjs.TemplateCode.eventsList2(runtimeScene);
}


{


gdjs.TemplateCode.eventsList3(runtimeScene);
}


{


gdjs.TemplateCode.eventsList4(runtimeScene);
}


{


gdjs.TemplateCode.eventsList5(runtimeScene);
}


{


gdjs.TemplateCode.eventsList9(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.TemplateCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("bed"), gdjs.TemplateCode.GDbedObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDPlayerObjects1Objects, gdjs.TemplateCode.mapOfGDgdjs_9546TemplateCode_9546GDbedObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}}

}


};

gdjs.TemplateCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.TemplateCode.GDPlatformObjects1.length = 0;
gdjs.TemplateCode.GDPlatformObjects2.length = 0;
gdjs.TemplateCode.GDPlatformObjects3.length = 0;
gdjs.TemplateCode.GDPlatformObjects4.length = 0;
gdjs.TemplateCode.GDPlayerObjects1.length = 0;
gdjs.TemplateCode.GDPlayerObjects2.length = 0;
gdjs.TemplateCode.GDPlayerObjects3.length = 0;
gdjs.TemplateCode.GDPlayerObjects4.length = 0;
gdjs.TemplateCode.GDghostObjects1.length = 0;
gdjs.TemplateCode.GDghostObjects2.length = 0;
gdjs.TemplateCode.GDghostObjects3.length = 0;
gdjs.TemplateCode.GDghostObjects4.length = 0;
gdjs.TemplateCode.GDGhost1RightObjects1.length = 0;
gdjs.TemplateCode.GDGhost1RightObjects2.length = 0;
gdjs.TemplateCode.GDGhost1RightObjects3.length = 0;
gdjs.TemplateCode.GDGhost1RightObjects4.length = 0;
gdjs.TemplateCode.GDGhost1LeftObjects1.length = 0;
gdjs.TemplateCode.GDGhost1LeftObjects2.length = 0;
gdjs.TemplateCode.GDGhost1LeftObjects3.length = 0;
gdjs.TemplateCode.GDGhost1LeftObjects4.length = 0;
gdjs.TemplateCode.GDPlatform2Objects1.length = 0;
gdjs.TemplateCode.GDPlatform2Objects2.length = 0;
gdjs.TemplateCode.GDPlatform2Objects3.length = 0;
gdjs.TemplateCode.GDPlatform2Objects4.length = 0;
gdjs.TemplateCode.GDCoinObjects1.length = 0;
gdjs.TemplateCode.GDCoinObjects2.length = 0;
gdjs.TemplateCode.GDCoinObjects3.length = 0;
gdjs.TemplateCode.GDCoinObjects4.length = 0;
gdjs.TemplateCode.GDNewTextObjects1.length = 0;
gdjs.TemplateCode.GDNewTextObjects2.length = 0;
gdjs.TemplateCode.GDNewTextObjects3.length = 0;
gdjs.TemplateCode.GDNewTextObjects4.length = 0;
gdjs.TemplateCode.GDNewText2Objects1.length = 0;
gdjs.TemplateCode.GDNewText2Objects2.length = 0;
gdjs.TemplateCode.GDNewText2Objects3.length = 0;
gdjs.TemplateCode.GDNewText2Objects4.length = 0;
gdjs.TemplateCode.GDNewSpriteObjects1.length = 0;
gdjs.TemplateCode.GDNewSpriteObjects2.length = 0;
gdjs.TemplateCode.GDNewSpriteObjects3.length = 0;
gdjs.TemplateCode.GDNewSpriteObjects4.length = 0;
gdjs.TemplateCode.GDWallObjects1.length = 0;
gdjs.TemplateCode.GDWallObjects2.length = 0;
gdjs.TemplateCode.GDWallObjects3.length = 0;
gdjs.TemplateCode.GDWallObjects4.length = 0;
gdjs.TemplateCode.GDMovingfrfrfObjects1.length = 0;
gdjs.TemplateCode.GDMovingfrfrfObjects2.length = 0;
gdjs.TemplateCode.GDMovingfrfrfObjects3.length = 0;
gdjs.TemplateCode.GDMovingfrfrfObjects4.length = 0;
gdjs.TemplateCode.GDdashObjects1.length = 0;
gdjs.TemplateCode.GDdashObjects2.length = 0;
gdjs.TemplateCode.GDdashObjects3.length = 0;
gdjs.TemplateCode.GDdashObjects4.length = 0;
gdjs.TemplateCode.GDjumpghostObjects1.length = 0;
gdjs.TemplateCode.GDjumpghostObjects2.length = 0;
gdjs.TemplateCode.GDjumpghostObjects3.length = 0;
gdjs.TemplateCode.GDjumpghostObjects4.length = 0;
gdjs.TemplateCode.GDhitskeleObjects1.length = 0;
gdjs.TemplateCode.GDhitskeleObjects2.length = 0;
gdjs.TemplateCode.GDhitskeleObjects3.length = 0;
gdjs.TemplateCode.GDhitskeleObjects4.length = 0;
gdjs.TemplateCode.GDDetector_9595tm_9595Objects1.length = 0;
gdjs.TemplateCode.GDDetector_9595tm_9595Objects2.length = 0;
gdjs.TemplateCode.GDDetector_9595tm_9595Objects3.length = 0;
gdjs.TemplateCode.GDDetector_9595tm_9595Objects4.length = 0;
gdjs.TemplateCode.GDbedObjects1.length = 0;
gdjs.TemplateCode.GDbedObjects2.length = 0;
gdjs.TemplateCode.GDbedObjects3.length = 0;
gdjs.TemplateCode.GDbedObjects4.length = 0;
gdjs.TemplateCode.GDBedWinObjects1.length = 0;
gdjs.TemplateCode.GDBedWinObjects2.length = 0;
gdjs.TemplateCode.GDBedWinObjects3.length = 0;
gdjs.TemplateCode.GDBedWinObjects4.length = 0;
gdjs.TemplateCode.GDBackgroundObjects1.length = 0;
gdjs.TemplateCode.GDBackgroundObjects2.length = 0;
gdjs.TemplateCode.GDBackgroundObjects3.length = 0;
gdjs.TemplateCode.GDBackgroundObjects4.length = 0;
gdjs.TemplateCode.GDSkeletonObjects1.length = 0;
gdjs.TemplateCode.GDSkeletonObjects2.length = 0;
gdjs.TemplateCode.GDSkeletonObjects3.length = 0;
gdjs.TemplateCode.GDSkeletonObjects4.length = 0;
gdjs.TemplateCode.GDSanity_9595BarObjects1.length = 0;
gdjs.TemplateCode.GDSanity_9595BarObjects2.length = 0;
gdjs.TemplateCode.GDSanity_9595BarObjects3.length = 0;
gdjs.TemplateCode.GDSanity_9595BarObjects4.length = 0;
gdjs.TemplateCode.GDPlayerObjects1.length = 0;
gdjs.TemplateCode.GDPlayerObjects2.length = 0;
gdjs.TemplateCode.GDPlayerObjects3.length = 0;
gdjs.TemplateCode.GDPlayerObjects4.length = 0;
gdjs.TemplateCode.GDBottomObjects1.length = 0;
gdjs.TemplateCode.GDBottomObjects2.length = 0;
gdjs.TemplateCode.GDBottomObjects3.length = 0;
gdjs.TemplateCode.GDBottomObjects4.length = 0;

gdjs.TemplateCode.eventsList10(runtimeScene);

return;

}

gdjs['TemplateCode'] = gdjs.TemplateCode;
