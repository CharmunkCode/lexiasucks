gdjs.LevelBadCode = {};
gdjs.LevelBadCode.GDPlayerObjects2_1final = [];

gdjs.LevelBadCode.GDPlatformObjects1= [];
gdjs.LevelBadCode.GDPlatformObjects2= [];
gdjs.LevelBadCode.GDPlatformObjects3= [];
gdjs.LevelBadCode.GDPlatformObjects4= [];
gdjs.LevelBadCode.GDPlatformObjects5= [];
gdjs.LevelBadCode.GDPlayerObjects1= [];
gdjs.LevelBadCode.GDPlayerObjects2= [];
gdjs.LevelBadCode.GDPlayerObjects3= [];
gdjs.LevelBadCode.GDPlayerObjects4= [];
gdjs.LevelBadCode.GDPlayerObjects5= [];
gdjs.LevelBadCode.GDghostObjects1= [];
gdjs.LevelBadCode.GDghostObjects2= [];
gdjs.LevelBadCode.GDghostObjects3= [];
gdjs.LevelBadCode.GDghostObjects4= [];
gdjs.LevelBadCode.GDghostObjects5= [];
gdjs.LevelBadCode.GDGhost1RightObjects1= [];
gdjs.LevelBadCode.GDGhost1RightObjects2= [];
gdjs.LevelBadCode.GDGhost1RightObjects3= [];
gdjs.LevelBadCode.GDGhost1RightObjects4= [];
gdjs.LevelBadCode.GDGhost1RightObjects5= [];
gdjs.LevelBadCode.GDGhost1LeftObjects1= [];
gdjs.LevelBadCode.GDGhost1LeftObjects2= [];
gdjs.LevelBadCode.GDGhost1LeftObjects3= [];
gdjs.LevelBadCode.GDGhost1LeftObjects4= [];
gdjs.LevelBadCode.GDGhost1LeftObjects5= [];
gdjs.LevelBadCode.GDPlatform2Objects1= [];
gdjs.LevelBadCode.GDPlatform2Objects2= [];
gdjs.LevelBadCode.GDPlatform2Objects3= [];
gdjs.LevelBadCode.GDPlatform2Objects4= [];
gdjs.LevelBadCode.GDPlatform2Objects5= [];
gdjs.LevelBadCode.GDCoinObjects1= [];
gdjs.LevelBadCode.GDCoinObjects2= [];
gdjs.LevelBadCode.GDCoinObjects3= [];
gdjs.LevelBadCode.GDCoinObjects4= [];
gdjs.LevelBadCode.GDCoinObjects5= [];
gdjs.LevelBadCode.GDNewTextObjects1= [];
gdjs.LevelBadCode.GDNewTextObjects2= [];
gdjs.LevelBadCode.GDNewTextObjects3= [];
gdjs.LevelBadCode.GDNewTextObjects4= [];
gdjs.LevelBadCode.GDNewTextObjects5= [];
gdjs.LevelBadCode.GDNewText2Objects1= [];
gdjs.LevelBadCode.GDNewText2Objects2= [];
gdjs.LevelBadCode.GDNewText2Objects3= [];
gdjs.LevelBadCode.GDNewText2Objects4= [];
gdjs.LevelBadCode.GDNewText2Objects5= [];
gdjs.LevelBadCode.GDNewSpriteObjects1= [];
gdjs.LevelBadCode.GDNewSpriteObjects2= [];
gdjs.LevelBadCode.GDNewSpriteObjects3= [];
gdjs.LevelBadCode.GDNewSpriteObjects4= [];
gdjs.LevelBadCode.GDNewSpriteObjects5= [];
gdjs.LevelBadCode.GDWallObjects1= [];
gdjs.LevelBadCode.GDWallObjects2= [];
gdjs.LevelBadCode.GDWallObjects3= [];
gdjs.LevelBadCode.GDWallObjects4= [];
gdjs.LevelBadCode.GDWallObjects5= [];
gdjs.LevelBadCode.GDMovingfrfrfObjects1= [];
gdjs.LevelBadCode.GDMovingfrfrfObjects2= [];
gdjs.LevelBadCode.GDMovingfrfrfObjects3= [];
gdjs.LevelBadCode.GDMovingfrfrfObjects4= [];
gdjs.LevelBadCode.GDMovingfrfrfObjects5= [];
gdjs.LevelBadCode.GDdashObjects1= [];
gdjs.LevelBadCode.GDdashObjects2= [];
gdjs.LevelBadCode.GDdashObjects3= [];
gdjs.LevelBadCode.GDdashObjects4= [];
gdjs.LevelBadCode.GDdashObjects5= [];
gdjs.LevelBadCode.GDjumpghostObjects1= [];
gdjs.LevelBadCode.GDjumpghostObjects2= [];
gdjs.LevelBadCode.GDjumpghostObjects3= [];
gdjs.LevelBadCode.GDjumpghostObjects4= [];
gdjs.LevelBadCode.GDjumpghostObjects5= [];
gdjs.LevelBadCode.GDhitskeleObjects1= [];
gdjs.LevelBadCode.GDhitskeleObjects2= [];
gdjs.LevelBadCode.GDhitskeleObjects3= [];
gdjs.LevelBadCode.GDhitskeleObjects4= [];
gdjs.LevelBadCode.GDhitskeleObjects5= [];
gdjs.LevelBadCode.GDDetector_9595tm_9595Objects1= [];
gdjs.LevelBadCode.GDDetector_9595tm_9595Objects2= [];
gdjs.LevelBadCode.GDDetector_9595tm_9595Objects3= [];
gdjs.LevelBadCode.GDDetector_9595tm_9595Objects4= [];
gdjs.LevelBadCode.GDDetector_9595tm_9595Objects5= [];
gdjs.LevelBadCode.GDbedObjects1= [];
gdjs.LevelBadCode.GDbedObjects2= [];
gdjs.LevelBadCode.GDbedObjects3= [];
gdjs.LevelBadCode.GDbedObjects4= [];
gdjs.LevelBadCode.GDbedObjects5= [];
gdjs.LevelBadCode.GDBedWinObjects1= [];
gdjs.LevelBadCode.GDBedWinObjects2= [];
gdjs.LevelBadCode.GDBedWinObjects3= [];
gdjs.LevelBadCode.GDBedWinObjects4= [];
gdjs.LevelBadCode.GDBedWinObjects5= [];
gdjs.LevelBadCode.GDBoosterObjects1= [];
gdjs.LevelBadCode.GDBoosterObjects2= [];
gdjs.LevelBadCode.GDBoosterObjects3= [];
gdjs.LevelBadCode.GDBoosterObjects4= [];
gdjs.LevelBadCode.GDBoosterObjects5= [];
gdjs.LevelBadCode.GDGolemObjects1= [];
gdjs.LevelBadCode.GDGolemObjects2= [];
gdjs.LevelBadCode.GDGolemObjects3= [];
gdjs.LevelBadCode.GDGolemObjects4= [];
gdjs.LevelBadCode.GDGolemObjects5= [];
gdjs.LevelBadCode.GDBackgroundObjects1= [];
gdjs.LevelBadCode.GDBackgroundObjects2= [];
gdjs.LevelBadCode.GDBackgroundObjects3= [];
gdjs.LevelBadCode.GDBackgroundObjects4= [];
gdjs.LevelBadCode.GDBackgroundObjects5= [];
gdjs.LevelBadCode.GDSkeletonObjects1= [];
gdjs.LevelBadCode.GDSkeletonObjects2= [];
gdjs.LevelBadCode.GDSkeletonObjects3= [];
gdjs.LevelBadCode.GDSkeletonObjects4= [];
gdjs.LevelBadCode.GDSkeletonObjects5= [];
gdjs.LevelBadCode.GDSanity_9595BarObjects1= [];
gdjs.LevelBadCode.GDSanity_9595BarObjects2= [];
gdjs.LevelBadCode.GDSanity_9595BarObjects3= [];
gdjs.LevelBadCode.GDSanity_9595BarObjects4= [];
gdjs.LevelBadCode.GDSanity_9595BarObjects5= [];
gdjs.LevelBadCode.GDPlayerObjects1= [];
gdjs.LevelBadCode.GDPlayerObjects2= [];
gdjs.LevelBadCode.GDPlayerObjects3= [];
gdjs.LevelBadCode.GDPlayerObjects4= [];
gdjs.LevelBadCode.GDPlayerObjects5= [];
gdjs.LevelBadCode.GDBottomObjects1= [];
gdjs.LevelBadCode.GDBottomObjects2= [];
gdjs.LevelBadCode.GDBottomObjects3= [];
gdjs.LevelBadCode.GDBottomObjects4= [];
gdjs.LevelBadCode.GDBottomObjects5= [];


gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LevelBadCode.GDPlayerObjects2});
gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDghostObjects2Objects = Hashtable.newFrom({"ghost": gdjs.LevelBadCode.GDghostObjects2});
gdjs.LevelBadCode.asyncCallback16734500 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects3);

{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects3[i].getBehavior("PlatformerObject").setCanNotAirJump();
}
}}
gdjs.LevelBadCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.LevelBadCode.GDPlayerObjects2) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.15), (runtimeScene) => (gdjs.LevelBadCode.asyncCallback16734500(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LevelBadCode.asyncCallback16737284 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects3);

{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects3[i].getBehavior("PlatformerObject").setCanNotAirJump();
}
}}
gdjs.LevelBadCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.LevelBadCode.GDPlayerObjects2) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.15), (runtimeScene) => (gdjs.LevelBadCode.asyncCallback16737284(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LevelBadCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() != "WalkRight" ) {
        isConditionTrue_0 = true;
        gdjs.LevelBadCode.GDPlayerObjects2[k] = gdjs.LevelBadCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.LevelBadCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationIndex(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkRight" ) {
        isConditionTrue_0 = true;
        gdjs.LevelBadCode.GDPlayerObjects2[k] = gdjs.LevelBadCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.LevelBadCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.LevelBadCode.GDghostObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDPlayerObjects2Objects, gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDghostObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Cooldown") >= 0.5;
}
if (isConditionTrue_0) {
/* Reuse gdjs.LevelBadCode.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Sanity_Bar"), gdjs.LevelBadCode.GDSanity_9595BarObjects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Cooldown");
}{for(var i = 0, len = gdjs.LevelBadCode.GDSanity_9595BarObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDSanity_9595BarObjects2[i].getBehavior("Animation").setAnimationIndex(gdjs.LevelBadCode.GDSanity_9595BarObjects2[i].getBehavior("Animation").getAnimationIndex() + (1));
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects2[i].returnVariable(gdjs.LevelBadCode.GDPlayerObjects2[i].getVariables().getFromIndex(1)).sub(1);
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 1, 0.1, 0.1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkRight" ) {
        isConditionTrue_0 = true;
        gdjs.LevelBadCode.GDPlayerObjects2[k] = gdjs.LevelBadCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.LevelBadCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkLeft" ) {
        isConditionTrue_0 = true;
        gdjs.LevelBadCode.GDPlayerObjects2[k] = gdjs.LevelBadCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.LevelBadCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() != "WalkLeft" ) {
        isConditionTrue_0 = true;
        gdjs.LevelBadCode.GDPlayerObjects2[k] = gdjs.LevelBadCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.LevelBadCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("WalkLeft");
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects2[i].getBehavior("Animation").resumeAnimation();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").getCurrentSpeed() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.LevelBadCode.GDPlayerObjects2[k] = gdjs.LevelBadCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkRight" ) {
        isConditionTrue_0 = true;
        gdjs.LevelBadCode.GDPlayerObjects2[k] = gdjs.LevelBadCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.LevelBadCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects2[i].resetTimer("Idle");
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").getCurrentSpeed() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.LevelBadCode.GDPlayerObjects2[k] = gdjs.LevelBadCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkLeft" ) {
        isConditionTrue_0 = true;
        gdjs.LevelBadCode.GDPlayerObjects2[k] = gdjs.LevelBadCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.LevelBadCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects2[i].resetTimer("Idle");
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("IdleLeft");
}
}}

}


{

gdjs.LevelBadCode.GDPlayerObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "RShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.LevelBadCode.GDPlayerObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects3);
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDPlayerObjects3[i].getBehavior("Animation").getAnimationName() == "WalkRight" ) {
        isConditionTrue_1 = true;
        gdjs.LevelBadCode.GDPlayerObjects3[k] = gdjs.LevelBadCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDPlayerObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.LevelBadCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.LevelBadCode.GDPlayerObjects2_1final.indexOf(gdjs.LevelBadCode.GDPlayerObjects3[j]) === -1 )
            gdjs.LevelBadCode.GDPlayerObjects2_1final.push(gdjs.LevelBadCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects3);
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDPlayerObjects3[i].getBehavior("Animation").getAnimationName() == "Idle" ) {
        isConditionTrue_1 = true;
        gdjs.LevelBadCode.GDPlayerObjects3[k] = gdjs.LevelBadCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDPlayerObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.LevelBadCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.LevelBadCode.GDPlayerObjects2_1final.indexOf(gdjs.LevelBadCode.GDPlayerObjects3[j]) === -1 )
            gdjs.LevelBadCode.GDPlayerObjects2_1final.push(gdjs.LevelBadCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.LevelBadCode.GDPlayerObjects2_1final, gdjs.LevelBadCode.GDPlayerObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDPlayerObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Dash") >= 1 ) {
        isConditionTrue_0 = true;
        gdjs.LevelBadCode.GDPlayerObjects2[k] = gdjs.LevelBadCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDPlayerObjects2.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.LevelBadCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects2[i].resetTimer("Dash");
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects2[i].addForce(1200, 0, 1);
}
}
{ //Subevents
gdjs.LevelBadCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.LevelBadCode.GDPlayerObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "RShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.LevelBadCode.GDPlayerObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects3);
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDPlayerObjects3[i].getBehavior("Animation").getAnimationName() == "WalkLeft" ) {
        isConditionTrue_1 = true;
        gdjs.LevelBadCode.GDPlayerObjects3[k] = gdjs.LevelBadCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDPlayerObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.LevelBadCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.LevelBadCode.GDPlayerObjects2_1final.indexOf(gdjs.LevelBadCode.GDPlayerObjects3[j]) === -1 )
            gdjs.LevelBadCode.GDPlayerObjects2_1final.push(gdjs.LevelBadCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.LevelBadCode.GDPlayerObjects2_1final, gdjs.LevelBadCode.GDPlayerObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDPlayerObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Dash") >= 1 ) {
        isConditionTrue_0 = true;
        gdjs.LevelBadCode.GDPlayerObjects2[k] = gdjs.LevelBadCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDPlayerObjects2.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.LevelBadCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects2[i].resetTimer("Dash");
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects2[i].addForce(-(1200), 0, 1);
}
}
{ //Subevents
gdjs.LevelBadCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects1[i].resetTimer("Dash");
}
}}

}


};gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDghostObjects2Objects = Hashtable.newFrom({"ghost": gdjs.LevelBadCode.GDghostObjects2});
gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDghostObjects2Objects = Hashtable.newFrom({"ghost": gdjs.LevelBadCode.GDghostObjects2});
gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDGhost1LeftObjects2Objects = Hashtable.newFrom({"Ghost1Left": gdjs.LevelBadCode.GDGhost1LeftObjects2});
gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDghostObjects2Objects = Hashtable.newFrom({"ghost": gdjs.LevelBadCode.GDghostObjects2});
gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDghostObjects1Objects = Hashtable.newFrom({"ghost": gdjs.LevelBadCode.GDghostObjects1});
gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDGhost1RightObjects1Objects = Hashtable.newFrom({"Ghost1Right": gdjs.LevelBadCode.GDGhost1RightObjects1});
gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDghostObjects1Objects = Hashtable.newFrom({"ghost": gdjs.LevelBadCode.GDghostObjects1});
gdjs.LevelBadCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Ghost1Left"), gdjs.LevelBadCode.GDGhost1LeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("Ghost1Right"), gdjs.LevelBadCode.GDGhost1RightObjects2);
{for(var i = 0, len = gdjs.LevelBadCode.GDGhost1RightObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDGhost1RightObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDGhost1LeftObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDGhost1LeftObjects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.LevelBadCode.GDghostObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDghostObjects2Objects);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ghost1Right"), gdjs.LevelBadCode.GDGhost1RightObjects2);
/* Reuse gdjs.LevelBadCode.GDghostObjects2 */
{for(var i = 0, len = gdjs.LevelBadCode.GDghostObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDghostObjects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.LevelBadCode.GDGhost1RightObjects2.length === 0 ) ? 0 :gdjs.LevelBadCode.GDGhost1RightObjects2[0].getPointX("")), (( gdjs.LevelBadCode.GDGhost1RightObjects2.length === 0 ) ? 0 :gdjs.LevelBadCode.GDGhost1RightObjects2[0].getPointY("")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost1Left"), gdjs.LevelBadCode.GDGhost1LeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.LevelBadCode.GDghostObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDghostObjects2Objects, gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDGhost1LeftObjects2Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickNearestObject(gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDghostObjects2Objects, (( gdjs.LevelBadCode.GDGhost1LeftObjects2.length === 0 ) ? 0 :gdjs.LevelBadCode.GDGhost1LeftObjects2[0].getPointX("")), (( gdjs.LevelBadCode.GDGhost1LeftObjects2.length === 0 ) ? 0 :gdjs.LevelBadCode.GDGhost1LeftObjects2[0].getPointY("")), false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ghost1Right"), gdjs.LevelBadCode.GDGhost1RightObjects2);
/* Reuse gdjs.LevelBadCode.GDghostObjects2 */
{for(var i = 0, len = gdjs.LevelBadCode.GDghostObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDghostObjects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.LevelBadCode.GDGhost1RightObjects2.length === 0 ) ? 0 :gdjs.LevelBadCode.GDGhost1RightObjects2[0].getPointX("")), (( gdjs.LevelBadCode.GDGhost1RightObjects2.length === 0 ) ? 0 :gdjs.LevelBadCode.GDGhost1RightObjects2[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDghostObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDghostObjects2[i].getBehavior("Animation").setAnimationIndex(gdjs.LevelBadCode.GDghostObjects2[i].getBehavior("Animation").getAnimationIndex() - (1));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost1Right"), gdjs.LevelBadCode.GDGhost1RightObjects1);
gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.LevelBadCode.GDghostObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDghostObjects1Objects, gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDGhost1RightObjects1Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickNearestObject(gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDghostObjects1Objects, (( gdjs.LevelBadCode.GDGhost1RightObjects1.length === 0 ) ? 0 :gdjs.LevelBadCode.GDGhost1RightObjects1[0].getPointX("")), (( gdjs.LevelBadCode.GDGhost1RightObjects1.length === 0 ) ? 0 :gdjs.LevelBadCode.GDGhost1RightObjects1[0].getPointY("")), false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ghost1Left"), gdjs.LevelBadCode.GDGhost1LeftObjects1);
/* Reuse gdjs.LevelBadCode.GDghostObjects1 */
{for(var i = 0, len = gdjs.LevelBadCode.GDghostObjects1.length ;i < len;++i) {
    gdjs.LevelBadCode.GDghostObjects1[i].getBehavior("Animation").setAnimationName("Left");
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDghostObjects1.length ;i < len;++i) {
    gdjs.LevelBadCode.GDghostObjects1[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.LevelBadCode.GDGhost1LeftObjects1.length === 0 ) ? 0 :gdjs.LevelBadCode.GDGhost1LeftObjects1[0].getPointX("")), (( gdjs.LevelBadCode.GDGhost1LeftObjects1.length === 0 ) ? 0 :gdjs.LevelBadCode.GDGhost1LeftObjects1[0].getPointY("")));
}
}}

}


};gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LevelBadCode.GDPlayerObjects2});
gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.LevelBadCode.GDCoinObjects2});
gdjs.LevelBadCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "game music (important).mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.LevelBadCode.GDCoinObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDPlayerObjects2Objects, gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDCoinObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.LevelBadCode.GDCoinObjects2 */
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.LevelBadCode.GDCoinObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDCoinObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.LevelBadCode.GDNewTextObjects1);
{for(var i = 0, len = gdjs.LevelBadCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.LevelBadCode.GDNewTextObjects1[i].getBehavior("Text").setText("= " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0))));
}
}}

}


};gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LevelBadCode.GDPlayerObjects2});
gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDBoosterObjects2Objects = Hashtable.newFrom({"Booster": gdjs.LevelBadCode.GDBoosterObjects2});
gdjs.LevelBadCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDPlayerObjects2[i].getX() <= 3200 ) {
        isConditionTrue_0 = true;
        gdjs.LevelBadCode.GDPlayerObjects2[k] = gdjs.LevelBadCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LevelBadCode.GDPlayerObjects2 */
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.LevelBadCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.LevelBadCode.GDPlayerObjects2[0].getPointX("")), "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Booster"), gdjs.LevelBadCode.GDBoosterObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDPlayerObjects2Objects, gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDBoosterObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.LevelBadCode.GDBoosterObjects2 */
{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.LevelBadCode.GDBoosterObjects2.length === 0 ) ? 0 :gdjs.LevelBadCode.GDBoosterObjects2[0].getPointY("")) + 120, "", 0);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Booster"), gdjs.LevelBadCode.GDBoosterObjects1);
{for(var i = 0, len = gdjs.LevelBadCode.GDBoosterObjects1.length ;i < len;++i) {
    gdjs.LevelBadCode.GDBoosterObjects1[i].hide();
}
}}

}


};gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDDetector_95959595tm_95959595Objects2Objects = Hashtable.newFrom({"Detector_tm_": gdjs.LevelBadCode.GDDetector_9595tm_9595Objects2});
gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LevelBadCode.GDPlayerObjects2});
gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.LevelBadCode.GDPlayerObjects1});
gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDSkeletonObjects1Objects = Hashtable.newFrom({"Skeleton": gdjs.LevelBadCode.GDSkeletonObjects1});
gdjs.LevelBadCode.asyncCallback16753444 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects5);

{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects5[i].setY(gdjs.LevelBadCode.GDPlayerObjects5[i].getY() - (60));
}
}}
gdjs.LevelBadCode.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.LevelBadCode.GDPlayerObjects4) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.LevelBadCode.asyncCallback16753444(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LevelBadCode.asyncCallback16752756 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("Skeleton"), gdjs.LevelBadCode.GDSkeletonObjects4);

{for(var i = 0, len = gdjs.LevelBadCode.GDSkeletonObjects4.length ;i < len;++i) {
    gdjs.LevelBadCode.GDSkeletonObjects4[i].getBehavior("Resizable").setHeight(gdjs.LevelBadCode.GDSkeletonObjects4[i].getBehavior("Resizable").getHeight() - (60));
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDSkeletonObjects4.length ;i < len;++i) {
    gdjs.LevelBadCode.GDSkeletonObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects4[i].setY(gdjs.LevelBadCode.GDPlayerObjects4[i].getY() - (65));
}
}
{ //Subevents
gdjs.LevelBadCode.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LevelBadCode.eventsList7 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save Player as it will be provided by the parent asyncObjectsList. */
for (const obj of gdjs.LevelBadCode.GDSkeletonObjects3) asyncObjectsList.addObject("Skeleton", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.LevelBadCode.asyncCallback16752756(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LevelBadCode.asyncCallback16752052 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Skeleton"), gdjs.LevelBadCode.GDSkeletonObjects3);

{for(var i = 0, len = gdjs.LevelBadCode.GDSkeletonObjects3.length ;i < len;++i) {
    gdjs.LevelBadCode.GDSkeletonObjects3[i].getBehavior("Resizable").setHeight(gdjs.LevelBadCode.GDSkeletonObjects3[i].getBehavior("Resizable").getHeight() - (60));
}
}
{ //Subevents
gdjs.LevelBadCode.eventsList7(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LevelBadCode.eventsList8 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.LevelBadCode.GDPlayerObjects2) asyncObjectsList.addObject("Player", obj);
for (const obj of gdjs.LevelBadCode.GDSkeletonObjects2) asyncObjectsList.addObject("Skeleton", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.LevelBadCode.asyncCallback16752052(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LevelBadCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.LevelBadCode.GDPlayerObjects1, gdjs.LevelBadCode.GDPlayerObjects2);

gdjs.copyArray(gdjs.LevelBadCode.GDSkeletonObjects1, gdjs.LevelBadCode.GDSkeletonObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.LevelBadCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.LevelBadCode.GDPlayerObjects2[0].getPointY("Feet")) <= (( gdjs.LevelBadCode.GDSkeletonObjects2.length === 0 ) ? 0 :gdjs.LevelBadCode.GDSkeletonObjects2[0].getPointY("Head")));
}
if (isConditionTrue_0) {
/* Reuse gdjs.LevelBadCode.GDSkeletonObjects2 */
{for(var i = 0, len = gdjs.LevelBadCode.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDSkeletonObjects2[i].getBehavior("Resizable").setHeight(gdjs.LevelBadCode.GDSkeletonObjects2[i].getBehavior("Resizable").getHeight() - (60));
}
}
{ //Subevents
gdjs.LevelBadCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.LevelBadCode.GDPlayerObjects1 */
/* Reuse gdjs.LevelBadCode.GDSkeletonObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.LevelBadCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.LevelBadCode.GDPlayerObjects1[0].getPointY("Feet")) > (( gdjs.LevelBadCode.GDSkeletonObjects1.length === 0 ) ? 0 :gdjs.LevelBadCode.GDSkeletonObjects1[0].getPointY("Head")));
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Cooldown") >= 0.5;
}
if (isConditionTrue_0) {
/* Reuse gdjs.LevelBadCode.GDPlayerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Sanity_Bar"), gdjs.LevelBadCode.GDSanity_9595BarObjects1);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Cooldown");
}{for(var i = 0, len = gdjs.LevelBadCode.GDSanity_9595BarObjects1.length ;i < len;++i) {
    gdjs.LevelBadCode.GDSanity_9595BarObjects1[i].getBehavior("Animation").setAnimationIndex(gdjs.LevelBadCode.GDSanity_9595BarObjects1[i].getBehavior("Animation").getAnimationIndex() + (1));
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects1[i].returnVariable(gdjs.LevelBadCode.GDPlayerObjects1[i].getVariables().getFromIndex(1)).sub(1);
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 1, 0.1, 0.1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.LevelBadCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.LevelBadCode.GDSkeletonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDSkeletonObjects2.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDSkeletonObjects2[i].getX() < (( gdjs.LevelBadCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.LevelBadCode.GDPlayerObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.LevelBadCode.GDSkeletonObjects2[k] = gdjs.LevelBadCode.GDSkeletonObjects2[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDSkeletonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDSkeletonObjects2.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDSkeletonObjects2[i].getVariableBoolean(gdjs.LevelBadCode.GDSkeletonObjects2[i].getVariables().getFromIndex(0), true) ) {
        isConditionTrue_0 = true;
        gdjs.LevelBadCode.GDSkeletonObjects2[k] = gdjs.LevelBadCode.GDSkeletonObjects2[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDSkeletonObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.LevelBadCode.GDSkeletonObjects2 */
{for(var i = 0, len = gdjs.LevelBadCode.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDSkeletonObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDSkeletonObjects2[i].getBehavior("Animation").setAnimationName("Walking Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.LevelBadCode.GDSkeletonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDSkeletonObjects2.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDSkeletonObjects2[i].getX() > (( gdjs.LevelBadCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.LevelBadCode.GDPlayerObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.LevelBadCode.GDSkeletonObjects2[k] = gdjs.LevelBadCode.GDSkeletonObjects2[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDSkeletonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDSkeletonObjects2.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDSkeletonObjects2[i].getVariableBoolean(gdjs.LevelBadCode.GDSkeletonObjects2[i].getVariables().getFromIndex(0), true) ) {
        isConditionTrue_0 = true;
        gdjs.LevelBadCode.GDSkeletonObjects2[k] = gdjs.LevelBadCode.GDSkeletonObjects2[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDSkeletonObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.LevelBadCode.GDSkeletonObjects2 */
{for(var i = 0, len = gdjs.LevelBadCode.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDSkeletonObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDSkeletonObjects2[i].getBehavior("Animation").setAnimationName("Walking Left");
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.LevelBadCode.GDSkeletonObjects2);
{for(var i = 0, len = gdjs.LevelBadCode.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDSkeletonObjects2[i].getBehavior("PlatformerObject").ignoreDefaultControls(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Detector_tm_"), gdjs.LevelBadCode.GDDetector_9595tm_9595Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDDetector_95959595tm_95959595Objects2Objects, gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.LevelBadCode.GDSkeletonObjects2);
{for(var i = 0, len = gdjs.LevelBadCode.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDSkeletonObjects2[i].setVariableBoolean(gdjs.LevelBadCode.GDSkeletonObjects2[i].getVariables().getFromIndex(0), true);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Detector_tm_"), gdjs.LevelBadCode.GDDetector_9595tm_9595Objects2);
{for(var i = 0, len = gdjs.LevelBadCode.GDDetector_9595tm_9595Objects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDDetector_9595tm_9595Objects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.LevelBadCode.GDSkeletonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDPlayerObjects1Objects, gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDSkeletonObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.LevelBadCode.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.LevelBadCode.GDPlayerObjects1});
gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDGolemObjects1Objects = Hashtable.newFrom({"Golem": gdjs.LevelBadCode.GDGolemObjects1});
gdjs.LevelBadCode.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.LevelBadCode.GDPlayerObjects1, gdjs.LevelBadCode.GDPlayerObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDPlayerObjects2[i].getAverageForce().getLength() >= 1200 ) {
        isConditionTrue_0 = true;
        gdjs.LevelBadCode.GDPlayerObjects2[k] = gdjs.LevelBadCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.LevelBadCode.GDGolemObjects1, gdjs.LevelBadCode.GDGolemObjects2);

/* Reuse gdjs.LevelBadCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects2[i].setX(gdjs.LevelBadCode.GDPlayerObjects2[i].getX() - (0.10 * (( gdjs.LevelBadCode.GDGolemObjects2.length === 0 ) ? 0 :gdjs.LevelBadCode.GDGolemObjects2[0].getPointX(""))));
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDGolemObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDGolemObjects2[i].returnVariable(gdjs.LevelBadCode.GDGolemObjects2[i].getVariables().getFromIndex(0)).sub(1);
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDGolemObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDGolemObjects2[i].addForce(2000, 0, 0);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Cooldown");
}}

}


{

/* Reuse gdjs.LevelBadCode.GDPlayerObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Cooldown") >= 0.5;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDPlayerObjects1[i].getAverageForce().getLength() < 1200 ) {
        isConditionTrue_0 = true;
        gdjs.LevelBadCode.GDPlayerObjects1[k] = gdjs.LevelBadCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDPlayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.LevelBadCode.GDGolemObjects1 */
/* Reuse gdjs.LevelBadCode.GDPlayerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Sanity_Bar"), gdjs.LevelBadCode.GDSanity_9595BarObjects1);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Cooldown");
}{for(var i = 0, len = gdjs.LevelBadCode.GDSanity_9595BarObjects1.length ;i < len;++i) {
    gdjs.LevelBadCode.GDSanity_9595BarObjects1[i].getBehavior("Animation").setAnimationIndex(gdjs.LevelBadCode.GDSanity_9595BarObjects1[i].getBehavior("Animation").getAnimationIndex() + (1));
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects1[i].returnVariable(gdjs.LevelBadCode.GDPlayerObjects1[i].getVariables().getFromIndex(1)).sub(1);
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 1, 0.1, 0.1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects1[i].setX(gdjs.LevelBadCode.GDPlayerObjects1[i].getX() - (0.10 * (( gdjs.LevelBadCode.GDGolemObjects1.length === 0 ) ? 0 :gdjs.LevelBadCode.GDGolemObjects1[0].getPointX(""))));
}
}}

}


};gdjs.LevelBadCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Golem"), gdjs.LevelBadCode.GDGolemObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDGolemObjects2.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDGolemObjects2[i].getX() < (( gdjs.LevelBadCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.LevelBadCode.GDPlayerObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.LevelBadCode.GDGolemObjects2[k] = gdjs.LevelBadCode.GDGolemObjects2[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDGolemObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LevelBadCode.GDGolemObjects2 */
{for(var i = 0, len = gdjs.LevelBadCode.GDGolemObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDGolemObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDGolemObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDGolemObjects2[i].getBehavior("Animation").setAnimationName("GolemRight");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Golem"), gdjs.LevelBadCode.GDGolemObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDGolemObjects2.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDGolemObjects2[i].getX() > (( gdjs.LevelBadCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.LevelBadCode.GDPlayerObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.LevelBadCode.GDGolemObjects2[k] = gdjs.LevelBadCode.GDGolemObjects2[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDGolemObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LevelBadCode.GDGolemObjects2 */
{for(var i = 0, len = gdjs.LevelBadCode.GDGolemObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDGolemObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDGolemObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDGolemObjects2[i].getBehavior("Animation").setAnimationName("GolemLeft");
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Golem"), gdjs.LevelBadCode.GDGolemObjects2);
{for(var i = 0, len = gdjs.LevelBadCode.GDGolemObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDGolemObjects2[i].getBehavior("PlatformerObject").ignoreDefaultControls(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Golem"), gdjs.LevelBadCode.GDGolemObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDPlayerObjects1Objects, gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDGolemObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.LevelBadCode.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.LevelBadCode.GDPlayerObjects1});
gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDbedObjects1Objects = Hashtable.newFrom({"bed": gdjs.LevelBadCode.GDbedObjects1});
gdjs.LevelBadCode.asyncCallback16764284 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Golem"), gdjs.LevelBadCode.GDGolemObjects3);

{for(var i = 0, len = gdjs.LevelBadCode.GDGolemObjects3.length ;i < len;++i) {
    gdjs.LevelBadCode.GDGolemObjects3[i].getBehavior("Resizable").setHeight(gdjs.LevelBadCode.GDGolemObjects3[i].getBehavior("Resizable").getHeight() - (60));
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDGolemObjects3.length ;i < len;++i) {
    gdjs.LevelBadCode.GDGolemObjects3[i].deleteFromScene(runtimeScene);
}
}}
gdjs.LevelBadCode.eventsList13 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.LevelBadCode.GDGolemObjects2) asyncObjectsList.addObject("Golem", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.LevelBadCode.asyncCallback16764284(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LevelBadCode.asyncCallback16764036 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Golem"), gdjs.LevelBadCode.GDGolemObjects2);

{for(var i = 0, len = gdjs.LevelBadCode.GDGolemObjects2.length ;i < len;++i) {
    gdjs.LevelBadCode.GDGolemObjects2[i].getBehavior("Resizable").setHeight(gdjs.LevelBadCode.GDGolemObjects2[i].getBehavior("Resizable").getHeight() - (60));
}
}
{ //Subevents
gdjs.LevelBadCode.eventsList13(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LevelBadCode.eventsList14 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.LevelBadCode.GDGolemObjects1) asyncObjectsList.addObject("Golem", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.LevelBadCode.asyncCallback16764036(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LevelBadCode.eventsList15 = function(runtimeScene) {

{


gdjs.LevelBadCode.eventsList2(runtimeScene);
}


{


gdjs.LevelBadCode.eventsList3(runtimeScene);
}


{


gdjs.LevelBadCode.eventsList4(runtimeScene);
}


{


gdjs.LevelBadCode.eventsList5(runtimeScene);
}


{


gdjs.LevelBadCode.eventsList10(runtimeScene);
}


{


gdjs.LevelBadCode.eventsList12(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("bed"), gdjs.LevelBadCode.GDbedObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDPlayerObjects1Objects, gdjs.LevelBadCode.mapOfGDgdjs_9546LevelBadCode_9546GDbedObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Cooldown");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDPlayerObjects1[i].getVariableNumber(gdjs.LevelBadCode.GDPlayerObjects1[i].getVariables().getFromIndex(1)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.LevelBadCode.GDPlayerObjects1[k] = gdjs.LevelBadCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Golem"), gdjs.LevelBadCode.GDGolemObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelBadCode.GDGolemObjects1.length;i<l;++i) {
    if ( gdjs.LevelBadCode.GDGolemObjects1[i].getVariableNumber(gdjs.LevelBadCode.GDGolemObjects1[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.LevelBadCode.GDGolemObjects1[k] = gdjs.LevelBadCode.GDGolemObjects1[i];
        ++k;
    }
}
gdjs.LevelBadCode.GDGolemObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LevelBadCode.GDGolemObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelBadCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.LevelBadCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.LevelBadCode.GDPlayerObjects1[i].setX(gdjs.LevelBadCode.GDPlayerObjects1[i].getX() - (0.10 * (( gdjs.LevelBadCode.GDGolemObjects1.length === 0 ) ? 0 :gdjs.LevelBadCode.GDGolemObjects1[0].getPointX(""))));
}
}{for(var i = 0, len = gdjs.LevelBadCode.GDGolemObjects1.length ;i < len;++i) {
    gdjs.LevelBadCode.GDGolemObjects1[i].getBehavior("Resizable").setHeight(gdjs.LevelBadCode.GDGolemObjects1[i].getBehavior("Resizable").getHeight() - (60));
}
}
{ //Subevents
gdjs.LevelBadCode.eventsList14(runtimeScene);} //End of subevents
}

}


};

gdjs.LevelBadCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.LevelBadCode.GDPlatformObjects1.length = 0;
gdjs.LevelBadCode.GDPlatformObjects2.length = 0;
gdjs.LevelBadCode.GDPlatformObjects3.length = 0;
gdjs.LevelBadCode.GDPlatformObjects4.length = 0;
gdjs.LevelBadCode.GDPlatformObjects5.length = 0;
gdjs.LevelBadCode.GDPlayerObjects1.length = 0;
gdjs.LevelBadCode.GDPlayerObjects2.length = 0;
gdjs.LevelBadCode.GDPlayerObjects3.length = 0;
gdjs.LevelBadCode.GDPlayerObjects4.length = 0;
gdjs.LevelBadCode.GDPlayerObjects5.length = 0;
gdjs.LevelBadCode.GDghostObjects1.length = 0;
gdjs.LevelBadCode.GDghostObjects2.length = 0;
gdjs.LevelBadCode.GDghostObjects3.length = 0;
gdjs.LevelBadCode.GDghostObjects4.length = 0;
gdjs.LevelBadCode.GDghostObjects5.length = 0;
gdjs.LevelBadCode.GDGhost1RightObjects1.length = 0;
gdjs.LevelBadCode.GDGhost1RightObjects2.length = 0;
gdjs.LevelBadCode.GDGhost1RightObjects3.length = 0;
gdjs.LevelBadCode.GDGhost1RightObjects4.length = 0;
gdjs.LevelBadCode.GDGhost1RightObjects5.length = 0;
gdjs.LevelBadCode.GDGhost1LeftObjects1.length = 0;
gdjs.LevelBadCode.GDGhost1LeftObjects2.length = 0;
gdjs.LevelBadCode.GDGhost1LeftObjects3.length = 0;
gdjs.LevelBadCode.GDGhost1LeftObjects4.length = 0;
gdjs.LevelBadCode.GDGhost1LeftObjects5.length = 0;
gdjs.LevelBadCode.GDPlatform2Objects1.length = 0;
gdjs.LevelBadCode.GDPlatform2Objects2.length = 0;
gdjs.LevelBadCode.GDPlatform2Objects3.length = 0;
gdjs.LevelBadCode.GDPlatform2Objects4.length = 0;
gdjs.LevelBadCode.GDPlatform2Objects5.length = 0;
gdjs.LevelBadCode.GDCoinObjects1.length = 0;
gdjs.LevelBadCode.GDCoinObjects2.length = 0;
gdjs.LevelBadCode.GDCoinObjects3.length = 0;
gdjs.LevelBadCode.GDCoinObjects4.length = 0;
gdjs.LevelBadCode.GDCoinObjects5.length = 0;
gdjs.LevelBadCode.GDNewTextObjects1.length = 0;
gdjs.LevelBadCode.GDNewTextObjects2.length = 0;
gdjs.LevelBadCode.GDNewTextObjects3.length = 0;
gdjs.LevelBadCode.GDNewTextObjects4.length = 0;
gdjs.LevelBadCode.GDNewTextObjects5.length = 0;
gdjs.LevelBadCode.GDNewText2Objects1.length = 0;
gdjs.LevelBadCode.GDNewText2Objects2.length = 0;
gdjs.LevelBadCode.GDNewText2Objects3.length = 0;
gdjs.LevelBadCode.GDNewText2Objects4.length = 0;
gdjs.LevelBadCode.GDNewText2Objects5.length = 0;
gdjs.LevelBadCode.GDNewSpriteObjects1.length = 0;
gdjs.LevelBadCode.GDNewSpriteObjects2.length = 0;
gdjs.LevelBadCode.GDNewSpriteObjects3.length = 0;
gdjs.LevelBadCode.GDNewSpriteObjects4.length = 0;
gdjs.LevelBadCode.GDNewSpriteObjects5.length = 0;
gdjs.LevelBadCode.GDWallObjects1.length = 0;
gdjs.LevelBadCode.GDWallObjects2.length = 0;
gdjs.LevelBadCode.GDWallObjects3.length = 0;
gdjs.LevelBadCode.GDWallObjects4.length = 0;
gdjs.LevelBadCode.GDWallObjects5.length = 0;
gdjs.LevelBadCode.GDMovingfrfrfObjects1.length = 0;
gdjs.LevelBadCode.GDMovingfrfrfObjects2.length = 0;
gdjs.LevelBadCode.GDMovingfrfrfObjects3.length = 0;
gdjs.LevelBadCode.GDMovingfrfrfObjects4.length = 0;
gdjs.LevelBadCode.GDMovingfrfrfObjects5.length = 0;
gdjs.LevelBadCode.GDdashObjects1.length = 0;
gdjs.LevelBadCode.GDdashObjects2.length = 0;
gdjs.LevelBadCode.GDdashObjects3.length = 0;
gdjs.LevelBadCode.GDdashObjects4.length = 0;
gdjs.LevelBadCode.GDdashObjects5.length = 0;
gdjs.LevelBadCode.GDjumpghostObjects1.length = 0;
gdjs.LevelBadCode.GDjumpghostObjects2.length = 0;
gdjs.LevelBadCode.GDjumpghostObjects3.length = 0;
gdjs.LevelBadCode.GDjumpghostObjects4.length = 0;
gdjs.LevelBadCode.GDjumpghostObjects5.length = 0;
gdjs.LevelBadCode.GDhitskeleObjects1.length = 0;
gdjs.LevelBadCode.GDhitskeleObjects2.length = 0;
gdjs.LevelBadCode.GDhitskeleObjects3.length = 0;
gdjs.LevelBadCode.GDhitskeleObjects4.length = 0;
gdjs.LevelBadCode.GDhitskeleObjects5.length = 0;
gdjs.LevelBadCode.GDDetector_9595tm_9595Objects1.length = 0;
gdjs.LevelBadCode.GDDetector_9595tm_9595Objects2.length = 0;
gdjs.LevelBadCode.GDDetector_9595tm_9595Objects3.length = 0;
gdjs.LevelBadCode.GDDetector_9595tm_9595Objects4.length = 0;
gdjs.LevelBadCode.GDDetector_9595tm_9595Objects5.length = 0;
gdjs.LevelBadCode.GDbedObjects1.length = 0;
gdjs.LevelBadCode.GDbedObjects2.length = 0;
gdjs.LevelBadCode.GDbedObjects3.length = 0;
gdjs.LevelBadCode.GDbedObjects4.length = 0;
gdjs.LevelBadCode.GDbedObjects5.length = 0;
gdjs.LevelBadCode.GDBedWinObjects1.length = 0;
gdjs.LevelBadCode.GDBedWinObjects2.length = 0;
gdjs.LevelBadCode.GDBedWinObjects3.length = 0;
gdjs.LevelBadCode.GDBedWinObjects4.length = 0;
gdjs.LevelBadCode.GDBedWinObjects5.length = 0;
gdjs.LevelBadCode.GDBoosterObjects1.length = 0;
gdjs.LevelBadCode.GDBoosterObjects2.length = 0;
gdjs.LevelBadCode.GDBoosterObjects3.length = 0;
gdjs.LevelBadCode.GDBoosterObjects4.length = 0;
gdjs.LevelBadCode.GDBoosterObjects5.length = 0;
gdjs.LevelBadCode.GDGolemObjects1.length = 0;
gdjs.LevelBadCode.GDGolemObjects2.length = 0;
gdjs.LevelBadCode.GDGolemObjects3.length = 0;
gdjs.LevelBadCode.GDGolemObjects4.length = 0;
gdjs.LevelBadCode.GDGolemObjects5.length = 0;
gdjs.LevelBadCode.GDBackgroundObjects1.length = 0;
gdjs.LevelBadCode.GDBackgroundObjects2.length = 0;
gdjs.LevelBadCode.GDBackgroundObjects3.length = 0;
gdjs.LevelBadCode.GDBackgroundObjects4.length = 0;
gdjs.LevelBadCode.GDBackgroundObjects5.length = 0;
gdjs.LevelBadCode.GDSkeletonObjects1.length = 0;
gdjs.LevelBadCode.GDSkeletonObjects2.length = 0;
gdjs.LevelBadCode.GDSkeletonObjects3.length = 0;
gdjs.LevelBadCode.GDSkeletonObjects4.length = 0;
gdjs.LevelBadCode.GDSkeletonObjects5.length = 0;
gdjs.LevelBadCode.GDSanity_9595BarObjects1.length = 0;
gdjs.LevelBadCode.GDSanity_9595BarObjects2.length = 0;
gdjs.LevelBadCode.GDSanity_9595BarObjects3.length = 0;
gdjs.LevelBadCode.GDSanity_9595BarObjects4.length = 0;
gdjs.LevelBadCode.GDSanity_9595BarObjects5.length = 0;
gdjs.LevelBadCode.GDPlayerObjects1.length = 0;
gdjs.LevelBadCode.GDPlayerObjects2.length = 0;
gdjs.LevelBadCode.GDPlayerObjects3.length = 0;
gdjs.LevelBadCode.GDPlayerObjects4.length = 0;
gdjs.LevelBadCode.GDPlayerObjects5.length = 0;
gdjs.LevelBadCode.GDBottomObjects1.length = 0;
gdjs.LevelBadCode.GDBottomObjects2.length = 0;
gdjs.LevelBadCode.GDBottomObjects3.length = 0;
gdjs.LevelBadCode.GDBottomObjects4.length = 0;
gdjs.LevelBadCode.GDBottomObjects5.length = 0;

gdjs.LevelBadCode.eventsList15(runtimeScene);

return;

}

gdjs['LevelBadCode'] = gdjs.LevelBadCode;
